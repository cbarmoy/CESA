# 🚀 Guide : Navigation Rapide dans CESA

## 📖 Qu'est-ce que la Navigation Rapide ?

La **Navigation Rapide** est un mode de chargement spécial qui permet de naviguer **instantanément** dans vos enregistrements EEG, même s'ils durent plusieurs heures.

### ✨ Avantages

- ⚡ **Navigation ultra-rapide** : Déplacement et zoom en temps réel
- 🎯 **Idéal pour les longues sessions** : Analysez des enregistrements de plusieurs heures sans ralentissement
- 💾 **Économe en mémoire** : Charge uniquement ce qui est affiché à l'écran

### 📊 Mode Standard vs Navigation Rapide

| Caractéristique | Mode Standard | Navigation Rapide |
|----------------|---------------|-------------------|
| **Vitesse de navigation** | Variable selon taille | Instantanée (< 50 ms) |
| **Préparation initiale** | Aucune | 5-10 minutes |
| **Espace disque** | Fichier EDF seulement | +10-20% |
| **Idéal pour** | Fichiers courts | Longues sessions |

---

## 🎯 Comment l'utiliser ?

### Première utilisation

1. **Chargez votre fichier EDF** :
   - Menu **Fichier → Ouvrir EDF+**
   - Sélectionnez votre fichier `.edf`

2. **Choisissez le mode de chargement** :
   - Une fenêtre apparaît avec deux options :
     - ⚡ **Navigation Rapide (Recommandé)**
     - 📂 **Mode Standard**

3. **Si vous choisissez Navigation Rapide** :
   - CESA vous demande si vous voulez créer le fichier optimisé
   - Cliquez sur **"Oui"** pour créer le fichier
   - Patientez quelques minutes (une seule fois !)
   - ✅ C'est prêt ! La navigation est maintenant instantanée

### Utilisations suivantes

Lorsque vous rechargez le même fichier EDF :
1. CESA détecte automatiquement le fichier optimisé existant
2. Sélectionnez **⚡ Navigation Rapide**
3. Le fichier optimisé est automatiquement utilisé
4. **Pas d'attente** : Navigation immédiate !

---

## ⏱️ Temps de création

Le temps nécessaire pour créer le fichier optimisé dépend :

| Durée d'enregistrement | Nombre de canaux | Temps estimé |
|------------------------|------------------|--------------|
| 2 heures | 16 canaux | ~2-3 minutes |
| 8 heures | 16 canaux | ~5-10 minutes |
| 24 heures | 32 canaux | ~20-30 minutes |

> 💡 **Astuce** : Créez le fichier optimisé en fin de journée, il sera prêt le lendemain matin !

---

## 💾 Espace disque

Le fichier optimisé occupe environ **10-20%** de la taille du fichier EDF d'origine.

**Exemple** :
- Fichier EDF : 500 MB
- Fichier optimisé : ~50-100 MB

Le fichier est créé dans un dossier portant le nom de votre fichier EDF suivi de `_ms`.

**Exemple** :
```
📁 Mes_Données/
  ├── 📄 patient_001.edf          (fichier original)
  └── 📁 patient_001_ms/           (fichier optimisé)
      └── 📁 levels/
          ├── lvl1/
          ├── lvl2/
          └── ...
```

---

## ❓ Questions Fréquentes

### Dois-je créer le fichier optimisé à chaque fois ?

**Non !** Le fichier optimisé est créé **une seule fois**. Ensuite, CESA le réutilise automatiquement à chaque chargement.

### Puis-je supprimer le fichier optimisé ?

**Oui**, sans problème. Vous pouvez toujours utiliser le Mode Standard avec le fichier EDF original.
Si vous voulez réactiver la Navigation Rapide, CESA vous proposera de recréer le fichier optimisé.

### Que se passe-t-il si j'interromps la création ?

CESA peut **reprendre** la création là où elle s'est arrêtée. Il suffit de relancer le processus.

### Le fichier EDF original est-il modifié ?

**Non**, jamais. Le fichier optimisé est créé séparément. Votre fichier EDF original reste intact.

### Puis-je partager le fichier optimisé ?

**Oui**, vous pouvez copier le dossier `_ms` avec votre fichier EDF. 
Cela évite à vos collègues de recréer le fichier optimisé.

---

## 🎓 Pour aller plus loin

### Voir le mode actif

La barre de statut en bas de CESA affiche le mode actif :
- ⚡ **Navigation Rapide** : Affiche les performances (latence, FPS)
- 📂 **Mode Standard** : Affichage classique

### Fichiers volumineux (> 10 Go)

Pour les très gros fichiers, vous pouvez créer le fichier optimisé en ligne de commande :

```bash
python cli.py build-pyramid --raw votre_fichier.edf --out votre_fichier_ms
```

Cette méthode permet de suivre la progression en temps réel.

---

## 📞 Support

Besoin d'aide ? Contactez :
- 📧 Email : come1.barmoy@supbiotech.fr
- 📚 Documentation : Consultez le README.md
- 🐛 Bug : Créez une issue sur GitHub

---

**CESA v3.0** - Développé par Côme Barmoy (Unité Neuropsychologie du Stress - IRBA)



