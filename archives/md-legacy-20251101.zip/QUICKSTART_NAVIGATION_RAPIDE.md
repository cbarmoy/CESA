# ⚡ Démarrage Rapide : Navigation Rapide

## 🎯 Pour les Nouveaux Utilisateurs

### Votre Premier Chargement (5 minutes)

#### Étape 1 : Ouvrir votre fichier
```
Menu → Fichier → Ouvrir EDF+
Sélectionnez votre fichier .edf
```

#### Étape 2 : Choisir "Navigation Rapide"
Une fenêtre apparaît avec deux options :

```
┌──────────────────────────────────────────┐
│ ⚡ Navigation Rapide (Recommandé) ✓      │
│   → Pour naviguer instantanément         │
│                                          │
│ 📂 Mode Standard                         │
│   → Pour chargement direct               │
└──────────────────────────────────────────┘
```

**Laissez "Navigation Rapide" sélectionné** (c'est le choix par défaut)

#### Étape 3 : Laisser le champ vide
```
┌──────────────────────────────────────────┐
│ Fichier existant (optionnel) :          │
│                                          │
│ 💡 Première utilisation ?                │
│    Laissez ce champ VIDE !               │
│                                          │
│ [___________________] [Parcourir...]     │
└──────────────────────────────────────────┘
```

**Ne mettez RIEN dans le champ !** Cliquez directement sur **"Continuer"**

#### Étape 4 : Créer le fichier
CESA vous demande :
```
┌──────────────────────────────────────────┐
│ ⚡ Navigation Rapide                     │
│                                          │
│ Pour activer la navigation instantanée,  │
│ CESA doit créer un fichier optimisé.    │
│                                          │
│ ⏱️  Durée : 5-10 minutes                │
│ 💾 Espace : ~10-20% du fichier          │
│ ✨ Ensuite : Navigation ultra-rapide !  │
│                                          │
│ [Oui] [Non] [Annuler]                   │
└──────────────────────────────────────────┘
```

**Cliquez sur "Oui"** et patientez quelques minutes ☕

#### Étape 5 : Profitez !
```
✅ Le fichier de navigation rapide a été créé !
   Vous pouvez maintenant naviguer instantanément.
```

🎉 **C'est tout !** La navigation est maintenant ultra-rapide !

---

## 🔄 Les Fois Suivantes (10 secondes)

Une fois le fichier créé, les prochains chargements seront **instantanés** :

1. **Ouvrir le même fichier EDF**
2. **Choisir "Navigation Rapide"**
3. **Laisser le champ vide** (CESA trouve automatiquement le fichier)
4. **Cliquer "Continuer"**
5. ✅ **Chargement immédiat !**

---

## 🆘 Si Vous Avez Une Erreur

### Erreur : "Dossier introuvable"

**Problème** : Vous avez mis un chemin dans le champ mais le dossier n'existe pas

**Solution** : **LAISSEZ LE CHAMP VIDE** et cliquez "Continuer"

### Erreur : "Pas un fichier valide"

**Problème** : Le dossier que vous avez sélectionné n'est pas un fichier de navigation rapide

**Solution** : 
1. **LAISSEZ LE CHAMP VIDE**
2. Cliquez "Continuer"
3. CESA créera automatiquement le bon fichier

### Vous Êtes Pressé ?

Si vous n'avez pas le temps d'attendre la création :

1. Choisissez **📂 Mode Standard** au lieu de Navigation Rapide
2. Cliquez "Continuer"
3. Le fichier se charge immédiatement (mais la navigation sera moins rapide)

---

## 📝 Règle d'Or

### ✅ PREMIÈRE FOIS → Laissez le champ VIDE

```
Fichier de navigation rapide existant (optionnel) :

[                    ] ← VIDE !

              [Continuer]
```

### ✅ FOIS SUIVANTES → Laissez AUSSI le champ vide

CESA trouve automatiquement le fichier créé précédemment !

---

## 💡 Astuces

### Où est créé le fichier ?

Le fichier optimisé est créé à côté de votre fichier EDF :

```
📁 Mes_Données/
  ├── 📄 patient_001.edf           ← Votre fichier original
  └── 📁 patient_001_ms/            ← Fichier créé automatiquement
```

### Combien de temps ça prend ?

| Durée d'enregistrement | Temps de création |
|------------------------|-------------------|
| 2 heures | ~2-3 minutes |
| 8 heures | ~5-10 minutes |
| 24 heures | ~20-30 minutes |

### Combien d'espace disque ?

Le fichier optimisé prend environ **10-20%** de la taille du fichier EDF.

**Exemple** :
- Fichier EDF : 500 MB
- Fichier optimisé : ~50-100 MB

### Je peux le supprimer ?

**Oui !** Si vous supprimez le dossier `_ms`, vous pouvez toujours :
- Utiliser le fichier EDF original en Mode Standard
- Recréer le fichier de Navigation Rapide quand vous voulez

---

## ❓ Questions Fréquentes

### Je dois créer le fichier à chaque fois ?

**Non !** Une seule fois suffit. Ensuite c'est automatique.

### Le fichier EDF est modifié ?

**Non, jamais.** Le fichier optimisé est créé séparément.

### Je peux partager le fichier optimisé ?

**Oui !** Vous pouvez copier le dossier `_ms` avec le fichier EDF.
Vos collègues n'auront pas besoin de le recréer.

### Ça marche avec tous les fichiers EDF ?

**Oui !** Tous les fichiers EDF sont supportés.

---

## 🎓 Récapitulatif Ultra-Simple

1. **Ouvrir fichier EDF** → Une fenêtre apparaît
2. **Choisir "Navigation Rapide"** → C'est déjà sélectionné
3. **Laisser le champ VIDE** → Ne rien écrire !
4. **Cliquer "Continuer"** → CESA demande si on crée
5. **Cliquer "Oui"** → Attendre 5-10 minutes
6. ✅ **C'est prêt !** Navigation ultra-rapide

**Les fois suivantes : étapes 1-4 seulement, chargement instantané !**

---

**CESA v3.0** - Navigation Rapide simplifiée
Développé par Côme Barmoy (Unité Neuropsychologie du Stress - IRBA)



