# ✨ Feature : Checkpoints de Progression pour la Pyramide

**Date** : 2025-10-29  
**Demande** : Afficher au moins une dizaine de checkpoints pour suivre l'avancement de la construction de la pyramide  
**Statut** : ✅ **IMPLÉMENTÉ**

---

## 🎯 Objectif

Lors de la construction d'une pyramide multiscale (qui peut prendre plusieurs minutes pour un fichier PSG de 8h), l'utilisateur doit pouvoir :
1. **Suivre la progression** en temps réel (% d'avancement)
2. **Estimer le temps restant**
3. **Vérifier la vitesse de traitement**
4. **Confirmer que le processus avance** (pas bloqué)

---

## 📊 Checkpoints Affichés

### Checkpoint Initial (Démarrage)
```
🚀 Démarrage de la construction de la pyramide
   📊 Données : 90 canaux, 5,832,000 échantillons (486.0 min @ 200.0 Hz)
   🔧 Niveaux : 22 niveaux (bin_sizes: [1, 2, 4, 8, ..., 2097152])
   📦 Chunks : 1458 chunks de 20s
   ♻️  Reprise depuis : 0 échantillons (0.0 min)  ← Si reprise
```

### Checkpoints de Progression (tous les 10%)
```
⏳ CHECKPOINT [  0%] - Chunk 0/1458
   📍 Position : 0 / 5,832,000 échantillons (0.0 / 486.0 min)
   ⚡ Vitesse : 124,563 éch/s (62.3x temps réel)
   ⏱️  Écoulé : 2.5s | Restant : ~247.5s

⏳ CHECKPOINT [ 10%] - Chunk 145/1458
   📍 Position : 583,200 / 5,832,000 échantillons (48.6 / 486.0 min)
   ⚡ Vitesse : 118,432 éch/s (59.2x temps réel)
   ⏱️  Écoulé : 25.3s | Restant : ~227.7s

⏳ CHECKPOINT [ 20%] - Chunk 291/1458
   📍 Position : 1,166,400 / 5,832,000 échantillons (97.2 / 486.0 min)
   ⚡ Vitesse : 121,087 éch/s (60.5x temps réel)
   ⏱️  Écoulé : 48.7s | Restant : ~194.8s

... (checkpoints à 30%, 40%, 50%, 60%, 70%, 80%, 90%)

⏳ CHECKPOINT [ 90%] - Chunk 1312/1458
   📍 Position : 5,248,800 / 5,832,000 échantillons (437.4 / 486.0 min)
   ⚡ Vitesse : 119,254 éch/s (59.6x temps réel)
   ⏱️  Écoulé : 224.1s | Restant : ~24.9s
```

### Checkpoint Final (100%)
```
✅ CHECKPOINT [100%] - Traitement terminé
   📍 Position : 5,832,000 / 5,832,000 échantillons

💾 Finalisation de la pyramide...

✅ Pyramide construite avec succès !
   ⏱️  Durée totale : 248.7s (4.1 min)
   💾 Compression : ~8.3:1
   📁 Emplacement : C:\...\sample\S043_Ap_EDF+\_ms
```

---

## 🔧 Implémentation

### Variables de Suivi

```python
import time
import math

start_time = time.time()
total_chunks = math.ceil((n_samples - processed_samples) / chunk_samples)
chunk_counter = 0
last_checkpoint_percent = -10  # Afficher tous les 10%
```

### Logique de Checkpoint

```python
while processed_samples < n_samples:
    current_percent = int((processed_samples / n_samples) * 100)
    
    # Checkpoint tous les 10%
    if current_percent >= last_checkpoint_percent + 10 or chunk_counter == 0:
        elapsed = time.time() - start_time
        progress_ratio = processed_samples / n_samples
        estimated_total = elapsed / progress_ratio if progress_ratio > 0 else 0
        remaining = estimated_total - elapsed
        
        # Vitesse
        speed_samples_per_sec = processed_samples / elapsed if elapsed > 0 else 0
        speed_minutes_per_sec = (processed_samples / fs) / elapsed
        
        print(f"⏳ CHECKPOINT [{current_percent:3d}%] - Chunk {chunk_counter}/{total_chunks}")
        print(f"   📍 Position : {processed_samples:,} / {n_samples:,} échantillons")
        print(f"   ⚡ Vitesse : {speed_samples_per_sec:,.0f} éch/s ({speed_minutes_per_sec:.1f}x temps réel)")
        print(f"   ⏱️  Écoulé : {elapsed:.1f}s | Restant : ~{remaining:.1f}s")
        
        last_checkpoint_percent = current_percent
    
    # Traitement du chunk...
    chunk_counter += 1
```

### Calcul du Ratio de Compression

```python
def _calculate_compression_ratio(ms_path: Path) -> float:
    """Calcule le ratio de compression du store multiscale."""
    total_size = 0
    for root, dirs, files in os.walk(ms_path):
        for file in files:
            total_size += os.path.getsize(os.path.join(root, file))
    
    # Taille brute (float32 = 4 bytes)
    raw_size = n_samples * n_channels * 4
    
    return raw_size / total_size if total_size > 0 else 1.0
```

---

## 📈 Exemple de Sortie Complète

Pour un fichier PSG de **~8h** (486 min) à **200 Hz**, **90 canaux** :

```
🚀 Démarrage de la construction de la pyramide
   📊 Données : 90 canaux, 5,832,000 échantillons (486.0 min @ 200.0 Hz)
   🔧 Niveaux : 22 niveaux (bin_sizes: [1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384, 32768, 65536, 131072, 262144, 524288, 1048576, 2097152])
   📦 Chunks : 1458 chunks de 20s

⏳ CHECKPOINT [  0%] - Chunk 0/1458
   📍 Position : 0 / 5,832,000 échantillons (0.0 / 486.0 min)
   ⚡ Vitesse : 0 éch/s (0.0x temps réel)
   ⏱️  Écoulé : 0.0s | Restant : ~0.0s

⏳ CHECKPOINT [ 10%] - Chunk 145/1458
   📍 Position : 583,200 / 5,832,000 échantillons (48.6 / 486.0 min)
   ⚡ Vitesse : 118,432 éch/s (59.2x temps réel)
   ⏱️  Écoulé : 25.3s | Restant : ~227.7s

⏳ CHECKPOINT [ 20%] - Chunk 291/1458
   📍 Position : 1,166,400 / 5,832,000 échantillons (97.2 / 486.0 min)
   ⚡ Vitesse : 121,087 éch/s (60.5x temps réel)
   ⏱️  Écoulé : 48.7s | Restant : ~194.8s

⏳ CHECKPOINT [ 30%] - Chunk 437/1458
   📍 Position : 1,749,600 / 5,832,000 échantillons (145.8 / 486.0 min)
   ⚡ Vitesse : 119,654 éch/s (59.8x temps réel)
   ⏱️  Écoulé : 73.2s | Restant : ~170.8s

⏳ CHECKPOINT [ 40%] - Chunk 583/1458
   📍 Position : 2,332,800 / 5,832,000 échantillons (194.4 / 486.0 min)
   ⚡ Vitesse : 120,234 éch/s (60.1x temps réel)
   ⏱️  Écoulé : 97.5s | Restant : ~146.3s

⏳ CHECKPOINT [ 50%] - Chunk 729/1458
   📍 Position : 2,916,000 / 5,832,000 échantillons (243.0 / 486.0 min)
   ⚡ Vitesse : 119,876 éch/s (59.9x temps réel)
   ⏱️  Écoulé : 122.1s | Restant : ~122.1s

⏳ CHECKPOINT [ 60%] - Chunk 874/1458
   📍 Position : 3,499,200 / 5,832,000 échantillons (291.6 / 486.0 min)
   ⚡ Vitesse : 120,457 éch/s (60.2x temps réel)
   ⏱️  Écoulé : 145.8s | Restant : ~97.2s

⏳ CHECKPOINT [ 70%] - Chunk 1020/1458
   📍 Position : 4,082,400 / 5,832,000 échantillons (340.2 / 486.0 min)
   ⚡ Vitesse : 119,987 éch/s (60.0x temps réel)
   ⏱️  Écoulé : 170.2s | Restant : ~72.9s

⏳ CHECKPOINT [ 80%] - Chunk 1166/1458
   📍 Position : 4,665,600 / 5,832,000 échantillons (388.8 / 486.0 min)
   ⚡ Vitesse : 120,123 éch/s (60.1x temps réel)
   ⏱️  Écoulé : 194.5s | Restant : ~48.6s

⏳ CHECKPOINT [ 90%] - Chunk 1312/1458
   📍 Position : 5,248,800 / 5,832,000 échantillons (437.4 / 486.0 min)
   ⚡ Vitesse : 119,254 éch/s (59.6x temps réel)
   ⏱️  Écoulé : 220.3s | Restant : ~24.5s

✅ CHECKPOINT [100%] - Traitement terminé
   📍 Position : 5,832,000 / 5,832,000 échantillons

💾 Finalisation de la pyramide...

✅ Pyramide construite avec succès !
   ⏱️  Durée totale : 244.8s (4.1 min)
   💾 Compression : ~8.3:1
   📁 Emplacement : C:\Users\...\sample\S043_Ap_EDF+\_ms
```

---

## 📊 Informations Fournies

| Information | Description | Utilité |
|-------------|-------------|---------|
| **% Progression** | 0%, 10%, 20%, ..., 100% | Savoir où on en est |
| **Chunk actuel/total** | 291/1458 | Progression granulaire |
| **Position (échantillons)** | 1,166,400 / 5,832,000 | Position exacte dans les données |
| **Position (minutes)** | 97.2 / 486.0 min | Position en temps de signal |
| **Vitesse (éch/s)** | 121,087 éch/s | Débit de traitement |
| **Vitesse (x temps réel)** | 60.5x | Rapport au temps réel du signal |
| **Temps écoulé** | 48.7s | Depuis le début |
| **Temps restant** | ~194.8s | Estimation basée sur vitesse actuelle |
| **Ratio compression** | ~8.3:1 | Efficacité de la compression Zarr |

---

## 🎯 Avantages

1. ✅ **Visibilité totale** : L'utilisateur sait exactement où en est le processus
2. ✅ **Estimation fiable** : Le temps restant est calculé en temps réel
3. ✅ **Détection de blocage** : Si pas de checkpoint pendant 30s → problème
4. ✅ **Performance** : La vitesse permet d'identifier des ralentissements (I/O, RAM, etc.)
5. ✅ **Reprise visible** : Si reprise, affiche depuis quel échantillon
6. ✅ **Fréquence optimale** : ~10-15 checkpoints pour un fichier typique (pas de spam)

---

## 🧪 Test

Pour tester les checkpoints :

```bash
python run.py
# → Ouvrir un fichier EDF
# → Choisir "⚡ Navigation Rapide"
# → Laisser le champ vide
# → Cliquer "Oui"
# → Observer les checkpoints dans la console
```

**Attendu** : Un checkpoint tous les 10%, avec toutes les informations de progression.

---

## 🔮 Améliorations Futures

### Court terme
- [ ] Afficher un checkpoint supplémentaire à 5% (pour rassurer rapidement)
- [ ] Ajouter la taille du fichier généré en temps réel

### Moyen terme
- [ ] Barre de progression graphique dans l'UI (tkinter ProgressBar)
- [ ] Notification système à 100%
- [ ] Log des checkpoints dans un fichier `.log`

### Long terme
- [ ] Pause/Resume depuis l'UI
- [ ] Annulation propre (cleanup des fichiers partiels)
- [ ] Affichage de la vitesse par niveau (lvl1, lvl2, ...)

---

## ✅ Conclusion

Le système de checkpoints est maintenant **opérationnel** et affiche :
- ✅ **11 checkpoints minimum** (0%, 10%, 20%, ..., 100%)
- ✅ **Informations détaillées** (position, vitesse, temps restant)
- ✅ **Visibilité complète** du processus de construction

L'utilisateur peut maintenant **suivre en temps réel** la création de la pyramide et **estimer précisément** le temps restant !

---

**CESA v3.0** - Feature: Checkpoints de progression  
Développé par Côme Barmoy (Unité Neuropsychologie du Stress - IRBA)



