# 📊 Import Excel dans CESA v3.0

## ✅ Fonctionnalité Disponible

L'import de fichiers Excel pour le scoring de sommeil est pleinement fonctionnel dans CESA v3.0.

---

## 📋 Formats Supportés

### **Types de Fichiers Excel :**
- ✅ **Fichiers .xls** (Excel 97-2003) - via xlrd >= 2.0.0
- ✅ **Fichiers .xlsx** (Excel 2007+) - via openpyxl >= 3.0.0
- ✅ **Fichiers .csv** - via pandas

### **Structure Attendue :**
Le fichier Excel doit contenir au minimum deux colonnes :
- **Colonne 1** : Stade de sommeil (W, N1, N2, N3, R/REM, U)
- **Colonne 2** : Heure de début (format temporel)

**Exemples de noms de colonnes reconnus :**
- Temps : "Time", "Temps", "Epoch", "Époque", "Heure", "Début", "Start"
- Stade : "Stage", "Stade", "Sleep", "Sommeil", "Score", "État", "State"

---

## 🛠️ Installation des Dépendances

### Méthode Automatique (Recommandée)
```bash
# Windows
INSTALL.bat

# Ligne de commande
pip install -r documentation/requirements.txt
```

### Méthode Manuelle
```bash
# Modules Excel
pip install xlrd>=2.0.0
pip install openpyxl>=3.0.0

# Autres dépendances
pip install pandas>=1.3.0
```

### Vérification de l'Installation
```python
# Test des modules
python -c "import xlrd; print('xlrd:', xlrd.__version__)"
python -c "import openpyxl; print('openpyxl:', openpyxl.__version__)"
python -c "import pandas; print('pandas:', pandas.__version__)"
```

---

## 🎯 Utilisation dans CESA

### **Étape 1 : Lancer CESA**
```bash
# Windows
RUN.bat

# Ligne de commande
python run.py
```

### **Étape 2 : Charger un Fichier EDF+**
1. **Menu** → Fichier → Ouvrir EDF+
2. **Sélectionner** votre fichier .edf
3. **Attendre** le chargement complet

### **Étape 3 : Importer le Scoring Excel**
1. **Menu** → Sommeil → Importer Scoring Excel
2. **Sélectionner** votre fichier .xls ou .xlsx
3. **Configurer** la synchronisation temporelle si nécessaire
4. **Valider** l'import

### **Étape 4 : Visualiser**
Le scoring apparaît automatiquement :
- **Sur l'histogramme EEG** : Bandes colorées par stade
- **Dans le menu Sommeil** : Indicateurs et statistiques
- **Graphique camembert** : Répartition des stades

---

## 📊 Exemple de Fichier Excel

### Structure Type :
```
| Sommeil | Heure de début       |
|---------|---------------------|
| Éveil   | 2022-06-14 23:58:30 |
| Éveil   | 2022-06-14 23:59:00 |
| N1      | 2022-06-14 23:59:30 |
| N2      | 2022-06-15 00:00:00 |
| N2      | 2022-06-15 00:00:30 |
| N3      | 2022-06-15 00:01:00 |
| REM     | 2022-06-15 00:01:30 |
```

### Fichier d'Exemple Inclus :
- **Emplacement** : `CESA/samples/S043_AP_sleep scoring.xls`
- **Contenu** : 763 époques de 30 secondes
- **Format** : Excel 97-2003 (.xls)

---

## 🔧 Résolution des Problèmes

### ❌ "Module xlrd manquant"
**Solution :**
```bash
pip install xlrd>=2.0.0
```

### ❌ "Module openpyxl manquant"
**Solution :**
```bash
pip install openpyxl>=3.0.0
```

### ❌ "Erreur lors de la lecture du fichier"
**Solutions possibles :**
1. **Vérifiez le format** : .xls ou .xlsx
2. **Vérifiez l'encodage** : UTF-8 recommandé
3. **Vérifiez la structure** :
   - Au moins 2 colonnes
   - Noms de colonnes reconnus
   - Pas de lignes vides au début
4. **Testez avec l'exemple** : `CESA/samples/S043_AP_sleep scoring.xls`

### ❌ "Synchronisation temporelle incorrecte"
**Solutions :**
1. **Vérifiez les horodatages** : Format compatible
2. **Ajustez manuellement** : Décalage temporel dans CESA
3. **Vérifiez la durée des époques** : Généralement 30 secondes

### ❌ "Colonnes non reconnues"
**Solution :**
Renommez vos colonnes avec des noms standards :
- **Pour le temps** : "Time", "Temps", "Heure de début"
- **Pour le stade** : "Stage", "Stade", "Sommeil"

---

## 📐 Stades de Sommeil Reconnus

### Variantes Acceptées :

#### Éveil (Wake)
- W, Wake, WAKE
- Éveil, ÉVEIL, Eveil, EVEIL

#### Sommeil Léger
- N1

#### Sommeil Profond Léger
- N2

#### Sommeil Profond
- N3

#### Sommeil Paradoxal (REM)
- R, REM, rem

#### Non Scoré / Incertain
- U, UNDEFINED, Undefined, undefined
- ARTIFACT, Artifact, artifact

**Note** : La reconnaissance est insensible à la casse et gère les accents.

---

## 🎨 Visualisation du Scoring

### Sur l'Histogramme EEG :
- **Bandes colorées** : Chaque stade a sa couleur
- **Hauteur proportionnelle** : Facilite la lecture
- **Légende** : Affichée en bas du graphique

### Graphique Camembert :
- **Menu** → Sommeil → Informations Scoring
- **Répartition** : Pourcentages par stade
- **Couleurs** : Selon le thème actif
- **Interactif** : Option "Inclure U"

### Indicateurs Numériques :
- **TST** : Temps total de sommeil
- **Efficacité** : Pourcentage du temps au lit passé à dormir
- **SOL** : Latence d'endormissement
- **WASO** : Éveil après endormissement
- **Latence REM** : Temps avant premier REM

---

## 🔬 Fonctionnalités Avancées

### Import Multiple :
- **Remplace** le scoring précédent
- **Conserve** les annotations manuelles si souhaité
- **Synchronisation** automatique avec l'EEG

### Export des Résultats :
- **CSV** : Export des indicateurs
- **Rapport texte** : Copie dans le presse-papiers
- **Graphiques** : Sauvegarde PNG/PDF

### Modification Post-Import :
- **Scoring manuel** : Modifier les stades directement
- **Annotations** : Ajouter des notes
- **Export modifié** : Sauvegarder les changements

---

## 📚 Documentation Technique

### Bibliothèques Utilisées :
- **xlrd** : Lecture des fichiers .xls
- **openpyxl** : Lecture/écriture des fichiers .xlsx
- **pandas** : Manipulation des données tabulaires
- **mne** : Intégration avec les données EEG

### Module Interne :
- **CESA/scoring_io.py** : Module d'import/export
- **Fonctions principales** :
  - `import_excel_scoring()` : Import depuis Excel
  - `import_edf_hypnogram()` : Import depuis EDF+
  - `export_scoring()` : Export vers fichier

---

## 🎉 Résultat

### ✅ Import Excel Fonctionnel
- **Multi-format** : .xls, .xlsx, .csv
- **Robuste** : Gestion des variantes de noms
- **Automatique** : Détection des colonnes
- **Visuel** : Affichage immédiat sur l'EEG

### ✅ Intégration Complète
- **Synchronisation** : Alignement temporel avec l'EEG
- **Visualisation** : Histogramme et graphiques
- **Indicateurs** : Calcul automatique
- **Export** : Sauvegarde des résultats

---

## 🚀 Guide Rapide

### Pour Importer un Scoring Excel :
1. **Lancez CESA** : `RUN.bat` ou `python run.py`
2. **Chargez l'EEG** : Menu → Fichier → Ouvrir EDF+
3. **Importez le scoring** : Menu → Sommeil → Importer Scoring Excel
4. **Sélectionnez le fichier** : .xls ou .xlsx
5. **Visualisez** : Le scoring apparaît automatiquement

### En Cas de Problème :
1. **Vérifiez les dépendances** : `pip install xlrd openpyxl`
2. **Testez avec l'exemple** : `CESA/samples/S043_AP_sleep scoring.xls`
3. **Consultez les logs** : Messages d'erreur dans la console
4. **Contactez le support** : come1.barmoy@supbiotech.fr

---

**Développé avec ❤️ pour l'Unité Neuropsychologie du Stress (IRBA)**  
**Auteur** : Côme Barmoy  
**Version** : 3.0.0  
**Date** : 2025-10-26  
**Licence** : MIT

---

*CESA v3.0 - Import Excel robuste et complet pour l'analyse du sommeil*
