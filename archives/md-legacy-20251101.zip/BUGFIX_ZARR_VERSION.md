# 🐛 Correction : Erreur Zarr v3

## ❌ Problème Identifié

Lors de la création du fichier de navigation rapide, l'erreur suivante se produit :

```
❌ Erreur lors de la création: Expected a BytesBytesCodec. 
   Got <class 'numcodecs.blosc.Blosc'> instead.
```

## 🔍 Cause

**Incompatibilité entre Zarr v2 et Zarr v3**

Notre code utilise l'API de **Zarr v2** (stable et largement utilisée), mais `pip install zarr` installait par défaut **Zarr v3.1.3** qui a une API complètement différente.

### Différences API :

**Zarr v2** (compatible) :
```python
import zarr
from numcodecs import Blosc

compressor = Blosc(cname="zstd", clevel=5)
dataset = zarr.create(shape=(10, 10), compressor=compressor)  # ✅ Fonctionne
```

**Zarr v3** (incompatible) :
```python
import zarr
from numcodecs import Blosc

compressor = Blosc(cname="zstd", clevel=5)
dataset = zarr.create(shape=(10, 10), compressor=compressor)  # ❌ Erreur
# Zarr v3 attend un BytesBytesCodec, pas un Blosc
```

## ✅ Solution Appliquée

### 1. Mise à jour de `documentation/requirements.txt`

**Avant** :
```
zarr>=2.16.0            # Multiscale min/max pyramids
```

**Après** :
```
zarr>=2.16.0,<3.0.0     # Multiscale min/max pyramids - v2 API
```

Le `<3.0.0` **force** l'installation de Zarr v2.x (compatible).

### 2. Désinstallation de Zarr v3

```bash
python -m pip uninstall -y zarr
```

### 3. Installation de Zarr v2

```bash
python -m pip install "zarr>=2.16.0,<3.0.0"
```

**Résultat** : Zarr v2.18.7 installé ✅

## 🎯 Test de Validation

Après correction, relancer CESA et charger un fichier EDF :

1. ✅ Dialogue "Mode de chargement" apparaît
2. ✅ Choisir "Navigation Rapide"
3. ✅ Laisser le champ vide
4. ✅ Cliquer "Continuer"
5. ✅ Cliquer "Oui" pour créer le fichier
6. ✅ **Création réussie sans erreur**
7. ✅ Navigation instantanée fonctionne

## 📊 Versions Compatibles

| Package | Version Compatible | Note |
|---------|-------------------|------|
| zarr | 2.16.0 - 2.18.x | ✅ API v2 (stable) |
| numcodecs | 0.12.0+ | ✅ Compatible Zarr v2 |
| blosc | N/A | Inclus dans numcodecs |

## ⚠️ Note pour les Futurs Développeurs

**Zarr v3** est une réécriture complète avec une nouvelle API. Pour supporter Zarr v3, il faudrait :

1. Réécrire `core/multiscale.py` pour utiliser l'API v3
2. Remplacer `Blosc` par `BytesBytesCodec` ou équivalent
3. Adapter toutes les opérations de création/lecture de datasets
4. Tester la compatibilité avec les fichiers existants

**Recommandation** : Rester sur Zarr v2 tant que la migration vers v3 n'est pas nécessaire.

## 🔄 Script de Migration (si nécessaire)

Si un utilisateur a déjà installé Zarr v3, voici comment revenir à v2 :

### Windows (PowerShell) :
```powershell
python -m pip uninstall -y zarr
python -m pip install "zarr>=2.16.0,<3.0.0"
```

### Linux/Mac :
```bash
python -m pip uninstall -y zarr && python -m pip install "zarr>=2.16.0,<3.0.0"
```

## 📝 Checklist Post-Installation

Après correction, vérifier :

- [ ] `python -m pip list | grep zarr` affiche une version 2.x
- [ ] CESA se lance sans erreur
- [ ] La création du fichier de navigation rapide fonctionne
- [ ] Aucune erreur "BytesBytesCodec" dans les logs

## 🎓 Pour l'Utilisateur Final

**Si vous voyez l'erreur "BytesBytesCodec"** :

1. Fermez CESA
2. Ouvrez un terminal (CMD ou PowerShell)
3. Tapez :
   ```
   python -m pip uninstall -y zarr
   python -m pip install "zarr>=2.16.0,<3.0.0"
   ```
4. Relancez CESA
5. ✅ L'erreur devrait disparaître

**Ou simplement** :
- Relancez `INSTALL.bat` qui installera automatiquement la bonne version

---

## 📅 Historique

- **2025-10-29** : Problème identifié et corrigé
- **Zarr v3.1.3** → **Zarr v2.18.7**
- Contrainte de version ajoutée à `requirements.txt`

---

**CESA v3.0** - Correction appliquée et testée
Développé par Côme Barmoy (Unité Neuropsychologie du Stress - IRBA)



