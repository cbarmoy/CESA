# 🖥️ Guide de Lancement CESA v3.0

## 🚀 Méthodes de Lancement

CESA v3.0 offre plusieurs méthodes pour lancer l'application selon vos préférences.

---

## 📋 Méthodes Disponibles

### 🥇 Méthode 1 : Lanceur Windows (Recommandé)
**Le plus simple pour Windows**

1. **Double-cliquez** sur `RUN.bat`
2. CESA se lance automatiquement
3. **C'est tout !**

**Avantages :**
- ✅ **Détection automatique** de Python
- ✅ **Recherche** dans tous les emplacements standard
- ✅ **Messages d'erreur** clairs
- ✅ **Pas de configuration** nécessaire

### 🥈 Méthode 2 : Ligne de Commande
**Pour tous les systèmes d'exploitation**

```bash
# Depuis le dossier principal
python run.py

# Ou avec python3
python3 run.py
```

**Avantages :**
- ✅ **Universel** : Windows, Linux, macOS
- ✅ **Direct** : Pas d'intermédiaire
- ✅ **Terminal** : Affiche tous les logs

### 🥉 Méthode 3 : Script d'Installation
**Pour configuration complète**

1. **Double-cliquez** sur `INSTALL.bat` (Windows)
2. **Suivez** les instructions à l'écran
3. **Installation** automatique des dépendances
4. **Test** de lancement automatique

**Avantages :**
- ✅ **Installation complète** automatique
- ✅ **Vérification** des dépendances
- ✅ **Configuration** du système
- ✅ **Test** de validation

---

## 🛠️ Création Manuelle d'un Raccourci (Optionnel)

Si vous souhaitez créer un raccourci personnalisé sur votre bureau :

### Windows

#### Méthode Graphique :
1. **Clic droit** sur le bureau → Nouveau → Raccourci
2. **Parcourir** jusqu'au dossier CESA
3. **Sélectionner** `RUN.bat`
4. **Nommer** : "CESA v3.0"
5. **Clic droit** sur le raccourci → Propriétés
6. **Cliquer** sur "Changer l'icône"
7. **Parcourir** : `CESA\logo\Icone_CESA.ico`
8. **Cliquer** OK

#### Méthode PowerShell (Automatique) :
```powershell
$WshShell = New-Object -comObject WScript.Shell
$Desktop = [Environment]::GetFolderPath("Desktop")
$Shortcut = $WshShell.CreateShortcut("$Desktop\CESA v3.0.lnk")
$Shortcut.TargetPath = "C:\Chemin\Vers\CESA\RUN.bat"
$Shortcut.WorkingDirectory = "C:\Chemin\Vers\CESA"
$Shortcut.IconLocation = "C:\Chemin\Vers\CESA\CESA\logo\Icone_CESA.ico"
$Shortcut.Description = "CESA v3.0 - EEG Studio Analysis"
$Shortcut.Save()
```

### Linux / macOS

#### Créer un Script de Lancement :
```bash
#!/bin/bash
cd /chemin/vers/CESA
python3 run.py
```

#### Rendre Exécutable :
```bash
chmod +x lancer_cesa.sh
```

#### Ajouter au Bureau (Linux) :
```bash
cp lancer_cesa.sh ~/Desktop/
```

---

## 🔧 Résolution des Problèmes

### ❌ "Python non trouvé"
**Solutions :**
1. **Utilisez RUN.bat** (détection automatique sur Windows)
2. **Installez Python** depuis https://www.python.org/downloads/
3. **Vérifiez l'installation** : `python --version`
4. **Ajoutez au PATH** : Cochez "Add Python to PATH" lors de l'installation

### ❌ "Module manquant"
**Solutions :**
1. **Installez les dépendances** :
   ```bash
   pip install -r documentation/requirements.txt
   ```
2. **Utilisez INSTALL.bat** pour installation automatique
3. **Vérifiez l'installation** :
   ```bash
   pip list
   ```

### ❌ "Erreur lors du lancement"
**Solutions :**
1. **Vérifiez la structure** : Assurez-vous que tous les fichiers sont présents
2. **Consultez les logs** : Regardez les messages d'erreur dans la console
3. **Relancez l'installation** : `INSTALL.bat`
4. **Contactez le support** : come1.barmoy@supbiotech.fr

### ❌ "Raccourci ne fonctionne pas"
**Solutions :**
1. **Vérifiez le chemin** : Assurez-vous que RUN.bat existe
2. **Vérifiez les permissions** : Clic droit → Propriétés → Débloquer
3. **Recréez le raccourci** : Suivez les étapes ci-dessus
4. **Utilisez RUN.bat directement** : Double-cliquez dans le dossier

---

## 📊 Comparaison des Méthodes

| Méthode | Windows | Linux/macOS | Facilité | Recommandé |
|---------|---------|-------------|----------|------------|
| **RUN.bat** | ✅ | ❌ | ⭐⭐⭐ | ✅ Windows |
| **python run.py** | ✅ | ✅ | ⭐⭐ | ✅ Universel |
| **INSTALL.bat** | ✅ | ❌ | ⭐ | 1ère install |
| **Raccourci manuel** | ✅ | ✅ | ⭐ | Optionnel |

---

## 🎯 Recommandations

### Pour Débutants
- **Utilisez RUN.bat** sur Windows (double-clic)
- **Ou python run.py** en ligne de commande

### Pour Première Installation
- **Utilisez INSTALL.bat** pour configuration complète
- Puis **RUN.bat** pour les lancements suivants

### Pour Utilisateurs Avancés
- **python run.py** en ligne de commande
- **Création de raccourci** personnalisé si souhaité

---

## 🎉 Résultat

### ✅ CESA v3.0 Accessible
- **Lancement simple** : RUN.bat ou python run.py
- **Multi-plateforme** : Windows, Linux, macOS
- **Flexible** : Plusieurs méthodes disponibles
- **Robuste** : Détection automatique de Python

### ✅ Options Disponibles
- **Lanceur Windows** : RUN.bat ✅
- **Ligne de commande** : python run.py ✅
- **Installation** : INSTALL.bat ✅
- **Raccourci** : Création manuelle possible ✅

---

## 🚀 Instructions Rapides

### Pour Lancer CESA Maintenant :
```bash
# Windows (méthode la plus simple)
Double-cliquez sur RUN.bat

# Ligne de commande (tous systèmes)
python run.py
```

### Pour Première Installation :
```bash
# Windows
Double-cliquez sur INSTALL.bat

# Linux/macOS
pip install -r documentation/requirements.txt
python run.py
```

---

**Développé avec ❤️ pour l'Unité Neuropsychologie du Stress (IRBA)**  
**Auteur** : Côme Barmoy  
**Version** : 3.0.0  
**Date** : 2025-10-26  
**Licence** : MIT

---

*CESA v3.0 - Lancement simple et flexible sur tous les systèmes*
