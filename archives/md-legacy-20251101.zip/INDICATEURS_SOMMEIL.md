# Indicateurs de Sommeil - Documentation CESA v3.0

## Vue d'ensemble

Cette fonctionnalité permet d'afficher des indicateurs avancés de sommeil avec la possibilité d'inclure ou d'exclure les périodes "U" (Non scorées/Incertaines) dans les calculs.

## Accès à la fonctionnalité

1. **Menu** : `🛏️ Sommeil` → `📈 Informations Scoring`
2. **Pré-requis** : Avoir chargé un scoring de sommeil (manuel ou automatique)

## Indicateurs calculés

### 📈 Statistiques générales
- **Nombre total d'époques** : Nombre total d'époques dans le scoring
- **Époques analysées** : Nombre d'époques incluses dans les calculs (avec ou sans U)
- **Durée par époque** : Durée d'une époque (généralement 30 secondes)
- **Temps total au lit (TIB)** : Durée totale de l'enregistrement

### 🛏️ Indicateurs de sommeil

#### ⏱️ Temps Total de Sommeil (TST)
- **Définition** : Somme des époques de sommeil (N1, N2, N3, REM)
- **Formule** : `TST = Nombre d'époques de sommeil × Durée d'époque`
- **Unités** : Heures et minutes
- **Utilité** : Mesure objective du temps passé à dormir

#### ✨ Efficacité du Sommeil
- **Définition** : Pourcentage du temps au lit passé à dormir
- **Formule** : `Efficacité = (TST / TIB) × 100`
- **Unités** : Pourcentage (%)
- **Interprétation** :
  - > 85% : Bonne efficacité
  - 75-85% : Efficacité moyenne
  - < 75% : Faible efficacité (possible insomnie)

#### ⏰ Latence d'Endormissement (SOL - Sleep Onset Latency)
- **Définition** : Temps écoulé avant la première époque de sommeil
- **Formule** : `SOL = Index de la première époque de sommeil × Durée d'époque`
- **Unités** : Minutes
- **Interprétation** :
  - < 10 min : Endormissement rapide
  - 10-20 min : Normal
  - > 20 min : Latence prolongée

#### 💤 Latence REM
- **Définition** : Temps écoulé avant la première époque de sommeil REM
- **Formule** : `Latence REM = Index de la première époque REM × Durée d'époque`
- **Unités** : Minutes
- **Interprétation** : Normalement entre 70-120 minutes

#### 😴 WASO (Wake After Sleep Onset)
- **Définition** : Temps d'éveil après le premier endormissement
- **Formule** : `WASO = Nombre d'époques d'éveil après la première époque de sommeil × Durée d'époque`
- **Unités** : Minutes
- **Interprétation** : Plus le WASO est élevé, plus le sommeil est fragmenté

#### 🌙 Temps d'Éveil Total
- **Définition** : Temps total passé éveillé pendant l'enregistrement
- **Unités** : Minutes

### 🥧 Graphique en Camembert
Un graphique circulaire interactif affiche visuellement la répartition des stades :
- **Couleurs** : Chaque stade a sa couleur caractéristique (selon le thème actif)
- **Pourcentages** : Affichés directement sur chaque portion
- **Mise en relief** : Le stade dominant est légèrement détaché
- **Mise à jour dynamique** : Le graphique se met à jour automatiquement lors du changement de l'option "Inclure U"

### 📊 Répartition des stades (tableau détaillé)
Tableau textuel détaillé montrant pour chaque stade de sommeil :
- Nombre d'époques
- Pourcentage du temps total
- Durée en minutes

## Option "Inclure les périodes U"

### ⚙️ Comportement

#### Option désactivée (par défaut)
- Les époques "U" sont **exclues** de tous les calculs
- Plus précis pour l'analyse du sommeil effectif
- Recommandé pour les analyses cliniques

#### Option activée
- Les époques "U" sont **incluses** dans les calculs
- Peut modifier significativement les résultats
- Utile pour évaluer l'impact des périodes non scorées

### Impact sur les indicateurs

| Indicateur | Impact de l'inclusion des U |
|------------|----------------------------|
| **TIB** | Aucun (toujours calculé sur tout l'enregistrement) |
| **TST** | Les U sont comptées comme du non-sommeil |
| **Efficacité** | Diminue si des U sont présentes |
| **SOL** | Peut augmenter si des U précèdent le premier sommeil |
| **Latence REM** | Peut augmenter si des U précèdent le premier REM |
| **WASO** | Peut augmenter si des U sont présentes après le premier endormissement |

## Fonctionnalités supplémentaires

### 📋 Copier le rapport
Copie un résumé des indicateurs dans le presse-papiers pour collage dans un document.

**Format du rapport** :
```
RAPPORT D'INDICATEURS DE SOMMEIL
==================================================

Temps au lit (TIB) : XXX.X min
Temps total de sommeil (TST) : XXX.X min
Efficacité du sommeil : XX.X%
Périodes U incluses/exclues

Généré le YYYY-MM-DD HH:MM:SS
```

### 💾 Exporter CSV
Exporte les indicateurs dans un fichier CSV pour analyse ultérieure.

**Structure du fichier CSV** :
| Indicateur | Valeur |
|------------|--------|
| Temps au lit (TIB) | XXX.X min |
| Temps total de sommeil (TST) | XXX.X min |
| Efficacité du sommeil | XX.X% |
| Périodes U | incluses/exclues |

## Exemples d'utilisation

### Cas 1 : Analyse clinique standard
1. Charger un fichier EDF avec scoring
2. Ouvrir `Sommeil` → `Informations Scoring`
3. **Laisser l'option "Inclure les périodes U" décochée**
4. Analyser les indicateurs
5. Exporter le rapport si nécessaire

### Cas 2 : Évaluation de la qualité du scoring
1. Charger un fichier EDF avec scoring
2. Ouvrir `Sommeil` → `Informations Scoring`
3. **Comparer les résultats avec et sans l'option "Inclure les périodes U"**
4. Une grande différence indique beaucoup de périodes non scorées

### Cas 3 : Recherche scientifique
1. Utiliser l'option selon le protocole de l'étude
2. Exporter les indicateurs en CSV
3. Importer dans un logiciel d'analyse statistique (R, Python, SPSS)

## Références scientifiques

Les indicateurs implémentés suivent les standards de l'American Academy of Sleep Medicine (AASM) :

- **TST** : Recommandations AASM pour la mesure du temps de sommeil total
- **Efficacité du sommeil** : Critère diagnostique des insomnies (DSM-5)
- **SOL** : Critère de latence d'endormissement pathologique
- **WASO** : Indicateur de fragmentation du sommeil
- **Latence REM** : Critère pour le diagnostic de narcolepsie

## Notes techniques

### Calcul robuste
- Les calculs gèrent automatiquement les variations de nomenclature des stades (W/Wake/WAKE/Éveil/ÉVEIL)
- Les stades de sommeil reconnus : N1, N2, N3, R, REM
- Les périodes non scorées : U, UNDEFINED, ARTIFACT

### Performance
- L'interface est optimisée pour gérer de grands ensembles de données
- Mise à jour en temps réel lors du changement de l'option "Inclure U"
- Scrollbar automatique pour les longs rapports

### Compatibilité
- Compatible avec tous les formats de scoring supportés par CESA
- Fonctionne avec le scoring automatique (YASA) et manuel (Excel/EDF+)

## Améliorations futures possibles

1. **Graphiques visuels** : Diagrammes circulaires pour la répartition des stades ✅ **IMPLÉMENTÉ**
2. **Comparaison nuit-nuit** : Évolution des indicateurs sur plusieurs enregistrements
3. **Seuils normatifs** : Ajout de zones de référence selon l'âge
4. **Export PDF** : Rapport complet formaté en PDF
5. **Statistiques par cycles** : Analyse cycle par cycle du sommeil

---

**Version** : 3.0.0  
**Date** : 2025-10-26  
**Auteur** : Côme Barmoy (Unité Neuropsychologie du Stress - IRBA)
**Projet** : CESA (Complex EEG Studio Analysis)
