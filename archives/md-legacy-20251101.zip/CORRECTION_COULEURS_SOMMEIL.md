# Correction des couleurs des stades de sommeil

## Problème identifié

Les stades "W" (Éveil) et "R" (REM) n'avaient pas de couleur définie dans certains contextes, notamment dans le graphique en camembert, car le système utilisait parfois des variantes de noms (Wake, WAKE, Éveil, REM, etc.) qui n'étaient pas reconnues par le gestionnaire de thèmes.

## Solution implémentée

### 1. Ajout d'alias dans le Theme Manager (`theme_manager.py`)

J'ai modifié tous les thèmes pour inclure des alias pour toutes les variantes de noms de stades :

**Pour l'Éveil (W):**
- Wake
- WAKE
- Éveil
- ÉVEIL
- Eveil
- EVEIL

**Pour le REM (R):**
- REM
- rem

**Pour les périodes non scorées (U):**
- UNDEFINED
- Undefined
- undefined
- ARTIFACT
- Artifact
- artifact

#### Exemple du code ajouté à chaque thème :

```python
def _define_stage_colors(self) -> Dict[str, str]:
    colors = {
        "W": "#1f77b4",    # Bleu
        "N1": "#ff7f0e",   # Orange
        "N2": "#2ca02c",   # Vert
        "N3": "#d62728",   # Rouge
        "R": "#9467bd",    # Violet
        "U": "#8c564b"     # Marron
    }
    # Ajouter des alias pour les variantes de noms
    colors.update({
        "Wake": colors["W"],
        "WAKE": colors["W"],
        "Éveil": colors["W"],
        "ÉVEIL": colors["W"],
        "Eveil": colors["W"],
        "EVEIL": colors["W"],
        "REM": colors["R"],
        "rem": colors["R"],
        "UNDEFINED": colors["U"],
        "Undefined": colors["U"],
        "undefined": colors["U"],
        "ARTIFACT": colors["U"],
        "Artifact": colors["U"],
        "artifact": colors["U"]
    })
    return colors
```

### 2. Système de fallback robuste dans le graphique en camembert

J'ai ajouté un système de couleurs par défaut qui garantit que tous les stades ont une couleur, même si le thème ne les définit pas :

```python
# Définir des couleurs par défaut robustes pour tous les stades possibles
default_colors = {
    'W': '#1f77b4',       # Bleu pour l'éveil
    'Wake': '#1f77b4',
    'WAKE': '#1f77b4',
    'Éveil': '#1f77b4',
    'ÉVEIL': '#1f77b4',
    'Eveil': '#1f77b4',
    'EVEIL': '#1f77b4',
    'N1': '#ff7f0e',      # Orange pour N1
    'N2': '#2ca02c',      # Vert pour N2
    'N3': '#d62728',      # Rouge pour N3
    'R': '#9467bd',       # Violet pour REM
    'REM': '#9467bd',
    'rem': '#9467bd',
    'U': '#8c564b',       # Marron pour U
    # ... autres alias
}

# Combiner avec les couleurs du thème (priorité au thème)
for stage, color in default_colors.items():
    if stage not in stage_colors_map:
        stage_colors_map[stage] = color
```

### 3. Logs de diagnostic

J'ai ajouté des logs pour faciliter le diagnostic des problèmes de couleurs :

```python
print(f"🎨 Camembert: {stage} ({stage_name}) -> couleur {color}")
```

## Résultat

Maintenant, **tous les stades de sommeil ont une couleur définie dans tous les thèmes** :

### Thème Default (🎨)
- **W (Éveil)** : Bleu `#1f77b4`
- **N1** : Orange `#ff7f0e`
- **N2** : Vert `#2ca02c`
- **N3** : Rouge `#d62728`
- **R (REM)** : Violet `#9467bd`
- **U (Non scoré)** : Marron `#8c564b`

### Thème Otilia (🦖🌸)
- **W (Éveil)** : Rose clair `#FFB6C1`
- **N1** : Rose `#FF69B4`
- **N2** : Rose foncé `#FF1493`
- **N3** : Rouge cramoisi `#DC143C`
- **R (REM)** : Magenta foncé `#8B008B`
- **U (Non scoré)** : Violet clair `#DDA0DD`

### Thème Fred (🧗‍♂️🌿)
- **W (Éveil)** : Vert clair `#90EE90`
- **N1** : Vert lime `#32CD32`
- **N2** : Vert forêt `#228B22`
- **N3** : Vert foncé `#006400`
- **R (REM)** : Vert `#008000`
- **U (Non scoré)** : Vert pâle `#98FB98`

### Thème Eléna (🐢🌊)
- **W (Éveil)** : Bleu ciel `#87CEEB`
- **N1** : Bleu acier `#4682B4`
- **N2** : Bleu `#1E90FF`
- **N3** : Bleu marine `#000080`
- **R (REM)** : Bleu royal `#4169E1`
- **U (Non scoré)** : Violet moyen `#9370DB`

## Compatibilité

Cette correction est **rétrocompatible** :
- ✅ Tous les anciens fichiers de scoring fonctionnent
- ✅ Toutes les variantes de noms sont reconnues
- ✅ Le graphique en camembert affiche correctement toutes les couleurs
- ✅ Fonctionne avec tous les thèmes (Default, Otilia, Fred, Eléna)

## Test

Pour vérifier que la correction fonctionne :

1. Charger un fichier EDF avec scoring de sommeil
2. Aller dans : **🛏️ Sommeil** → **📈 Informations Scoring**
3. Observer le graphique en camembert
4. Vérifier que **tous les stades ont une couleur distincte**
5. Changer de thème et vérifier que les couleurs changent
6. Vérifier les logs dans la console : `🎨 Camembert: [stage] -> couleur [code couleur]`

## Fichiers modifiés

1. **`CESA/theme_manager.py`** : Ajout d'alias dans tous les thèmes
   - `DefaultTheme._define_stage_colors()`
   - `OtiliaTheme._define_stage_colors()`
   - `FredTheme._define_stage_colors()`
   - `ElenaTheme._define_stage_colors()`

2. **`CESA/eeg_studio_fixed.py`** : Système de fallback robuste
   - `_update_sleep_indicators()` - Code du graphique en camembert

---

**Date de correction** : 2025-10-26  
**Version** : CESA 1.0  
**Statut** : ✅ Corrigé et testé


