# 🧪 Guide de Test : Navigation Rapide

## 📋 Checklist de Test

### ✅ Test 1 : Chargement avec Navigation Rapide (Première fois)

**Objectif** : Vérifier la création automatique du fichier optimisé

**Étapes** :
1. Lancer CESA : `python run.py`
2. Cliquer sur **Fichier → Ouvrir EDF+**
3. Sélectionner un fichier EDF de test
4. ✅ **Vérifier** : Le dialogue "Mode de chargement des données" apparaît
5. ✅ **Vérifier** : Deux sections sont visibles :
   - ⚡ Navigation Rapide (Recommandé) [sélectionné par défaut]
   - 📂 Mode Standard
6. Laisser "Navigation Rapide" sélectionné
7. Laisser le champ "Fichier de navigation rapide" vide
8. Cliquer sur **Continuer**
9. ✅ **Vérifier** : Message "⚡ Navigation Rapide" apparaît
10. ✅ **Vérifier** : Trois options sont proposées :
    - Oui = Créer le fichier maintenant
    - Non = Sélectionner un fichier existant
    - Annuler = Utiliser le mode standard
11. Cliquer sur **Oui**
12. ✅ **Vérifier** : Barre de progression "⚡ Création du fichier de navigation rapide..."
13. Attendre la fin de la création (quelques minutes)
14. ✅ **Vérifier** : Message "✅ Succès" avec confirmation
15. ✅ **Vérifier** : CESA affiche les données
16. ✅ **Vérifier** : Message final "Mode: ⚡ Navigation Rapide"

**Résultat attendu** :
- Fichier créé dans `votre_fichier_ms/`
- Navigation fluide et instantanée
- Pas d'erreur dans les logs

---

### ✅ Test 2 : Chargement avec Navigation Rapide (Fichier existant)

**Objectif** : Vérifier la réutilisation d'un fichier optimisé existant

**Pré-requis** : Avoir effectué le Test 1

**Étapes** :
1. Lancer CESA : `python run.py`
2. Cliquer sur **Fichier → Ouvrir EDF+**
3. Sélectionner le **même** fichier EDF que le Test 1
4. ✅ **Vérifier** : Le dialogue "Mode de chargement" apparaît
5. Sélectionner "⚡ Navigation Rapide"
6. Dans le champ "Fichier de navigation rapide", cliquer **Parcourir...**
7. Sélectionner le dossier `votre_fichier_ms` créé au Test 1
8. Cliquer sur **Continuer**
9. ✅ **Vérifier** : Chargement immédiat (< 5 secondes)
10. ✅ **Vérifier** : Message "Mode: ⚡ Navigation Rapide"

**Résultat attendu** :
- Chargement instantané sans création
- Navigation fluide
- Pas d'erreur

---

### ✅ Test 3 : Chargement en Mode Standard

**Objectif** : Vérifier que le mode standard fonctionne toujours

**Étapes** :
1. Lancer CESA : `python run.py`
2. Cliquer sur **Fichier → Ouvrir EDF+**
3. Sélectionner un fichier EDF
4. ✅ **Vérifier** : Le dialogue "Mode de chargement" apparaît
5. Sélectionner **📂 Mode Standard**
6. Cliquer sur **Continuer**
7. ✅ **Vérifier** : Chargement direct sans autre dialogue
8. ✅ **Vérifier** : Message "Mode: 📂 Mode Standard"

**Résultat attendu** :
- Chargement direct sans préparation
- Fonctionnement normal de CESA
- Pas d'erreur

---

### ✅ Test 4 : Annulation du Dialogue

**Objectif** : Vérifier que l'annulation fonctionne correctement

**Étapes** :
1. Lancer CESA : `python run.py`
2. Cliquer sur **Fichier → Ouvrir EDF+**
3. Sélectionner un fichier EDF
4. ✅ **Vérifier** : Le dialogue "Mode de chargement" apparaît
5. Cliquer sur **Annuler**
6. ✅ **Vérifier** : Retour au mode standard automatiquement
7. ✅ **Vérifier** : CESA affiche les données normalement

**Résultat attendu** :
- Pas d'erreur
- Chargement en mode standard
- Application fonctionnelle

---

### ✅ Test 5 : Sélection d'un Fichier Existant

**Objectif** : Vérifier la sélection manuelle d'un fichier optimisé

**Pré-requis** : Avoir un fichier optimisé existant

**Étapes** :
1. Lancer CESA : `python run.py`
2. Cliquer sur **Fichier → Ouvrir EDF+**
3. Sélectionner un fichier EDF
4. ✅ **Vérifier** : Le dialogue "Mode de chargement" apparaît
5. Sélectionner "⚡ Navigation Rapide"
6. Laisser le champ vide et cliquer **Continuer**
7. ✅ **Vérifier** : Message de création apparaît
8. Cliquer sur **Non** (Sélectionner un fichier existant)
9. ✅ **Vérifier** : Dialogue de sélection de dossier apparaît
10. Sélectionner le dossier `votre_fichier_ms`
11. ✅ **Vérifier** : Chargement avec le fichier sélectionné

**Résultat attendu** :
- Possibilité de sélectionner manuellement
- Chargement avec le fichier choisi
- Pas d'erreur

---

### ✅ Test 6 : Gestion d'Erreur (Fichier Invalide)

**Objectif** : Vérifier la gestion des erreurs

**Étapes** :
1. Lancer CESA : `python run.py`
2. Cliquer sur **Fichier → Ouvrir EDF+**
3. Sélectionner un fichier EDF
4. Sélectionner "⚡ Navigation Rapide"
5. Dans le champ "Fichier de navigation rapide", sélectionner un dossier **vide** ou **invalide**
6. Cliquer sur **Continuer**
7. ✅ **Vérifier** : Message d'erreur clair
8. ✅ **Vérifier** : Proposition de fallback vers mode standard
9. ✅ **Vérifier** : CESA continue de fonctionner

**Résultat attendu** :
- Message d'erreur compréhensible
- Fallback automatique vers mode standard
- Application stable

---

### ✅ Test 7 : Interface Visuelle

**Objectif** : Vérifier la clarté de l'interface

**Étapes** :
1. Lancer CESA : `python run.py`
2. Cliquer sur **Fichier → Ouvrir EDF+**
3. Sélectionner un fichier EDF
4. ✅ **Vérifier** : Le dialogue est visuellement clair
5. ✅ **Vérifier** : Les emojis sont affichés correctement (⚡, 📂)
6. ✅ **Vérifier** : Les descriptions sont lisibles
7. ✅ **Vérifier** : Les boutons sont bien positionnés
8. ✅ **Vérifier** : Les cadres (LabelFrame) sont distincts
9. ✅ **Vérifier** : La couleur verte est visible pour Navigation Rapide
10. ✅ **Vérifier** : Le texte est compréhensible pour un non-technique

**Résultat attendu** :
- Interface claire et professionnelle
- Texte accessible à tous
- Pas de termes techniques confusants

---

### ✅ Test 8 : Performance de Navigation

**Objectif** : Vérifier que la navigation rapide est vraiment rapide

**Pré-requis** : Fichier chargé en mode Navigation Rapide

**Étapes** :
1. Charger un fichier EDF en mode Navigation Rapide
2. ✅ **Vérifier** : Utiliser les flèches ← → pour naviguer
3. ✅ **Vérifier** : Déplacement instantané (< 100 ms perceptible)
4. ✅ **Vérifier** : Utiliser le zoom + -
5. ✅ **Vérifier** : Zoom instantané
6. ✅ **Vérifier** : Vérifier la barre de statut pour les métriques

**Résultat attendu** :
- Navigation fluide et instantanée
- Pas de lag perceptible
- FPS ≥ 30 dans la barre de statut

---

## 📊 Rapport de Test

### Test effectué le : ___________

| Test | Statut | Notes |
|------|--------|-------|
| Test 1 : Première création | ☐ Pass ☐ Fail | |
| Test 2 : Fichier existant | ☐ Pass ☐ Fail | |
| Test 3 : Mode Standard | ☐ Pass ☐ Fail | |
| Test 4 : Annulation | ☐ Pass ☐ Fail | |
| Test 5 : Sélection manuelle | ☐ Pass ☐ Fail | |
| Test 6 : Gestion d'erreur | ☐ Pass ☐ Fail | |
| Test 7 : Interface | ☐ Pass ☐ Fail | |
| Test 8 : Performance | ☐ Pass ☐ Fail | |

### Bugs trouvés :

1. ________________________________________________
2. ________________________________________________
3. ________________________________________________

### Suggestions d'amélioration :

1. ________________________________________________
2. ________________________________________________
3. ________________________________________________

---

## 🐛 Bugs Connus et Solutions

### Bug : "cannot access local variable 'selected_mode'"

**Symptôme** : Erreur au chargement du fichier  
**Cause** : Variable non définie  
**Solution** : ✅ Corrigé (ajout du dialogue ModeSelector)

### Bug : Dialogue ne s'affiche pas

**Symptôme** : Chargement direct sans dialogue  
**Cause** : ModeSelector non appelé  
**Solution** : Vérifier que `ModeSelector(self.root)` est bien appelé

---

## 📝 Notes de Test

- **Environnement de test** : 
  - OS : Windows / Mac / Linux
  - Python : 3.x
  - CESA : v3.0

- **Fichiers de test recommandés** :
  - Petit fichier (< 100 MB) pour tests rapides
  - Gros fichier (> 500 MB) pour tests de performance
  - Fichier multi-canaux (> 20 canaux)

- **Temps de test total estimé** : ~30-45 minutes

---

**CESA v3.0** - Navigation Rapide
Développé par Côme Barmoy (Unité Neuropsychologie du Stress - IRBA)



