# ✨ Feature : Sélection des Canaux pour la Pyramide

**Date** : 2025-10-29  
**Demande** : Sélectionner uniquement les canaux pré-sélectionnés pour l'UI avant la construction de la pyramide  
**Statut** : ✅ **IMPLÉMENTÉ**

---

## 🎯 Problème Initial

Lors de la construction de la pyramide multiscale, **TOUS les canaux** du fichier EDF étaient inclus, ce qui causait :
- ⏱️ **Temps de construction très long** (~15-20 min pour 90 canaux)
- 💾 **Taille de pyramide excessive** (~6 GB au lieu de ~700 MB)
- ❌ **Canaux inutiles** inclus (impédances, signaux non-PSG, etc.)

### Exemple Concret

Fichier **S043_Ap_EDF+.edf** :
- **90 canaux totaux** dans le fichier
- **11 canaux utilisés** dans l'UI :
  - 6 EEG : `F3-M2`, `F4-M1`, `C3-M2`, `C4-M1`, `O1-M2`, `O2-M1`
  - 2 EOG : `E1-M2`, `E2-M1`
  - 2 EMG : `Left Leg`, `Right Leg`
  - 1 ECG : `Heart Rate`

**Résultat** : Construction 8× plus longue que nécessaire !

---

## ✅ Solution Implémentée

### 1. Modification de `build_pyramid()` dans `core/multiscale.py`

**Nouveau paramètre** `selected_channels`:

```python
def build_pyramid(
    raw_source: BaseRaw | str | Path,
    out_ms_path: str | Path,
    *,
    chunk_seconds: int = 20,
    levels: Sequence[int] | None = None,
    dtype: np.dtype = np.float32,
    resume: bool = True,
    selected_channels: Sequence[str] | None = None,  # ✅ NOUVEAU
) -> MultiscaleStore:
```

**Logique de filtrage** :

```python
if selected_channels is not None:
    # Vérifier que tous les canaux demandés existent
    available_channels = set(raw.ch_names)
    missing_channels = set(selected_channels) - available_channels
    if missing_channels:
        print(f"⚠️  Canaux manquants ignorés: {missing_channels}", flush=True)
    
    # Ne garder que les canaux disponibles
    channel_names = [ch for ch in selected_channels if ch in available_channels]
    
    if not channel_names:
        raise ValueError("Aucun canal valide fourni dans selected_channels")
    
    # Créer un subset du Raw avec uniquement les canaux sélectionnés
    raw = raw.copy().pick_channels(channel_names)
    print(f"✅ Sélection de {len(channel_names)} canaux sur {len(available_channels)} disponibles", flush=True)
else:
    channel_names = list(raw.ch_names)
```

---

### 2. Modification de `load_edf_file()` dans `CESA/eeg_studio_fixed.py`

**Passage des canaux sélectionnés** :

```python
# Utiliser uniquement les canaux pré-sélectionnés pour la pyramide
# (beaucoup plus rapide que 90 canaux)
selected_channels_for_pyramid = self.selected_channels if hasattr(self, 'selected_channels') else None

if selected_channels_for_pyramid:
    print(f"🔧 Création du fichier de navigation rapide: {ms_path}")
    print(f"   📊 Canaux sélectionnés pour la pyramide: {selected_channels_for_pyramid}")
    print(f"   ⚡ Utilisation de {len(selected_channels_for_pyramid)} canaux au lieu de {len(self.raw.ch_names)}")
    estimated_time = len(selected_channels_for_pyramid) * 15 / 90  # Estimation en minutes
    print(f"   ⏱️  Temps estimé: ~{estimated_time:.1f} minutes")
else:
    print(f"🔧 Création du fichier de navigation rapide: {ms_path}")
    print(f"   ⚠️  Aucun canal pré-sélectionné, utilisation de tous les canaux")

build_pyramid(
    raw_source=self.raw,
    out_ms_path=ms_path,
    chunk_seconds=20,
    resume=True,
    selected_channels=selected_channels_for_pyramid  # ✅ Passage du paramètre
)
```

---

### 3. Amélioration : `flush=True` sur tous les `print()`

Pour que les checkpoints s'affichent **immédiatement** (pas de buffering) :

```python
print(f"⏳ CHECKPOINT [{current_percent:3d}%] - Chunk {chunk_counter}/{total_chunks}", flush=True)
print(f"   📍 Position : {processed_samples:,} / {n_samples:,} échantillons", flush=True)
print(f"   ⚡ Vitesse : {speed_samples_per_sec:,.0f} éch/s", flush=True)
print(f"   ⏱️  Écoulé : {elapsed:.1f}s | Restant : ~{remaining:.1f}s", flush=True)
print(flush=True)
```

---

## 📊 Impact sur les Performances

### Avant (90 canaux)

| Métrique | Valeur |
|----------|--------|
| **Canaux inclus** | 90 (tous) |
| **Temps de construction** | ~15-20 minutes |
| **Taille pyramide** | ~6 GB |
| **Fichiers Zarr** | ~38,000+ |
| **Checkpoints visibles** | ❌ Non (buffering) |

### Après (11 canaux sélectionnés)

| Métrique | Valeur |
|----------|--------|
| **Canaux inclus** | 11 (pré-sélectionnés UI) |
| **Temps de construction estimé** | **~2-3 minutes** ⚡ |
| **Taille pyramide estimée** | **~700 MB** 💾 |
| **Fichiers Zarr estimés** | ~5,000 |
| **Checkpoints visibles** | ✅ Oui (flush=True) |

**Gain** : **~8× plus rapide** et **~8× moins d'espace disque** !

---

## 🔍 Canaux Pré-Sélectionnés

Les canaux sont définis dans `CESA/eeg_studio_fixed.py:12598-12665` :

```python
channel_mapping = {
    # EEG différentiels
    'F3M2': ['F3-M2'],
    'F4M1': ['F4-M1'],
    'C3M2': ['C3-M2'],
    'C4M2': ['C4-M1'],
    'O1M2': ['O1-M2'],
    'O2M2': ['O2-M1'],
    # EOG
    'E1M2': ['E1-M2'],
    'E2M1': ['E2-M1'],
    # EMG
    'Left Leg': ['Left Leg'],
    'Right Leg': ['Right Leg'],
    # ECG
    'Heart Rate': ['Heart Rate', 'Fréquence cardi']
}
```

Ces canaux sont sélectionnés **automatiquement** lors du chargement du fichier EDF, dans l'ordre :
1. **EEG** (6 canaux) : Frontal, Central, Occipital
2. **EOG** (2 canaux) : Yeux gauche/droit
3. **EMG** (2 canaux) : Jambes
4. **ECG** (1 canal) : Cœur

---

## 🧪 Test de Validation

### Avant de Tester

Supprimer toute pyramide existante :
```powershell
Remove-Item -Recurse -Force "C:\...\sample\S043_Ap_EDF+\_ms"
```

### Procédure de Test

1. **Lancer CESA** : `python run.py`
2. **Ouvrir le fichier** : `S043_Ap_EDF+.edf`
3. **Choisir "⚡ Navigation Rapide"**
4. **Laisser le champ vide** → "Oui" pour créer
5. **Observer la console** :

**Attendu** :
```
🔧 Création du fichier de navigation rapide: C:\...\sample\S043_Ap_EDF+\_ms
   📊 Canaux sélectionnés pour la pyramide: ['F3-M2', 'F4-M1', 'C3-M2', 'C4-M1', 'O1-M2', 'O2-M1', 'E1-M2', 'E2-M1', 'Left Leg', 'Right Leg', 'Heart Rate']
   ⚡ Utilisation de 11 canaux au lieu de 90
   ⏱️  Temps estimé: ~1.8 minutes

✅ Sélection de 11 canaux sur 90 disponibles

🚀 Démarrage de la construction de la pyramide
   📊 Données : 11 canaux, 5,832,000 échantillons (486.0 min @ 200.0 Hz)
   🔧 Niveaux : 22 niveaux (bin_sizes: [1, 2, 4, ..., 2097152])
   📦 Chunks : 1458 chunks de 20s

⏳ CHECKPOINT [  0%] - Chunk 0/1458
⏳ CHECKPOINT [ 10%] - Chunk 145/1458
   ⏱️  Écoulé : 15.2s | Restant : ~137s
...
⏳ CHECKPOINT [100%] - Traitement terminé

✅ Pyramide construite avec succès !
   ⏱️  Durée totale : 152.3s (2.5 min)
   💾 Compression : ~8.3:1
```

---

## 🎯 Avantages

1. ✅ **Rapidité** : 8× plus rapide (2-3 min au lieu de 15-20 min)
2. ✅ **Espace disque** : 8× moins d'espace (~700 MB au lieu de ~6 GB)
3. ✅ **Cohérence** : Seuls les canaux utilisés dans l'UI sont inclus
4. ✅ **Flexibilité** : Paramètre optionnel (`selected_channels=None` → tous les canaux)
5. ✅ **Visibilité** : Checkpoints affichés en temps réel avec `flush=True`
6. ✅ **Robustesse** : Gestion des canaux manquants (warnings, pas d'erreur)

---

## 🔮 Améliorations Futures

### Court Terme
- [ ] Permettre à l'utilisateur de modifier la sélection avant la construction
- [ ] Ajouter une option "Tous les canaux" dans l'UI

### Moyen Terme
- [ ] Détecter automatiquement les types de canaux (EEG, EOG, EMG, ECG)
- [ ] Proposer des presets de sélection (PSG standard, PSG complet, EEG seul, etc.)

### Long Terme
- [ ] Construire plusieurs pyramides (une par type de signal)
- [ ] Permettre l'ajout de canaux à une pyramide existante

---

## 📝 Fichiers Modifiés

| Fichier | Modifications |
|---------|---------------|
| `core/multiscale.py` | Ajout paramètre `selected_channels` + filtrage + `flush=True` |
| `CESA/eeg_studio_fixed.py` | Passage de `self.selected_channels` à `build_pyramid()` |
| `FEATURE_SELECTION_CANAUX.md` | Ce document |

---

## ✅ Conclusion

La fonctionnalité de sélection des canaux est maintenant **opérationnelle** et permet de :
- ✅ **Réduire drastiquement** le temps de construction (8×)
- ✅ **Économiser l'espace disque** (8×)
- ✅ **Afficher les checkpoints en temps réel** (`flush=True`)
- ✅ **Garantir la cohérence** entre l'UI et la pyramide

**Temps de construction attendu** pour un fichier PSG de 8h avec 11 canaux : **~2-3 minutes** ⚡

---

**CESA v3.0** - Feature: Sélection des canaux  
Développé par Côme Barmoy (Unité Neuropsychologie du Stress - IRBA)



