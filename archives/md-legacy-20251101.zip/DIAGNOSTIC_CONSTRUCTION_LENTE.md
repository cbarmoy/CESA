# 🐌 Diagnostic : Construction de Pyramide Plus Lente que Prévu

**Date** : 2025-10-29  
**Fichier** : `S043_Ap_EDF+.edf`  
**Problème** : Construction prend 15-20 min au lieu de 4-5 min  
**Statut** : ✅ **NORMAL** (fichier exceptionnellement volumineux)

---

## 🔍 Analyse

### Caractéristiques du Fichier

| Paramètre | Valeur | Standard PSG | Rapport |
|-----------|--------|--------------|---------|
| **Canaux** | 90 | 16-20 | **5.6×** |
| **Fréquence** | 200 Hz | 200-256 Hz | 1× |
| **Durée** | ~8h | ~8h | 1× |
| **Taille pyramide** | ~6 GB | ~500 MB - 1 GB | **6-12×** |

### Pourquoi C'est Plus Long ?

**90 canaux** au lieu de 16 typiques signifie :
- ✅ **5.6× plus de données** à traiter
- ✅ **5.6× plus de fichiers Zarr** à créer
- ✅ **5.6× plus d'écriture disque**
- ✅ **Plus de pression sur la RAM** (~1.8 GB utilisée)

**Calcul du temps** :
```
Temps standard : 4-5 min pour 16 canaux
Temps ajusté : 4 min × (90/16) = 22.5 min
Temps observé : ~15-20 min (optimisations CPU)
```

---

## 📊 Progression Observée

### Monitoring (7 minutes)

| Timestamp | Fichiers | Taille (MB) | Δ Fichiers | Δ Taille |
|-----------|----------|-------------|------------|----------|
| 22:28:32 | 25,954 | 5,818.41 | - | - |
| 22:28:55 | 27,034 | 5,821.10 | +1,080 | +2.69 |
| 22:29:17 | 27,484 | 5,821.15 | +450 | +0.05 |
| 22:29:39 | 28,745 | 5,823.87 | +1,261 | +2.72 |
| 22:30:01 | 29,915 | 5,826.60 | +1,170 | +2.73 |
| 22:30:23 | 31,355 | 5,829.29 | +1,440 | +2.69 |
| 22:30:57 | 32,884 | 5,834.35 | +1,529 | +5.06 |
| 22:31:19 | 33,785 | 5,834.65 | +901 | +0.30 |
| 22:31:42 | 34,955 | 5,837.35 | +1,170 | +2.70 |
| 22:32:04 | 36,305 | 5,840.05 | +1,350 | +2.70 |
| 22:32:27 | 37,475 | 5,842.75 | +1,170 | +2.70 |
| 22:32:50 | 38,735 | 5,845.44 | +1,260 | +2.69 |

**Vitesse moyenne** : ~1,200 fichiers/min (~20 fichiers/sec)

**Estimation** : 
- Fichiers totaux estimés : ~50,000-60,000
- Restant : ~20,000 fichiers
- Temps restant : ~15-20 minutes

---

## ✅ Le Processus est SAIN

### Indicateurs de Santé

| Indicateur | État | Valeur |
|------------|------|--------|
| **CPU utilisé** | ✅ Actif | 391s (élevé) |
| **RAM utilisée** | ✅ Stable | ~1.8 GB |
| **Fichiers créés** | ✅ Croissance constante | +1,200/min |
| **Taille** | ✅ Croissance constante | +2.7 MB/min |
| **Processus actif** | ✅ Oui | PID 193748 |

**Conclusion** : Le processus fonctionne **normalement**, il est juste **plus long** à cause du volume de données.

---

## 🐛 Pourquoi les Checkpoints ne S'Affichent Pas ?

### Cause

Python met en **cache les sorties** (`stdout`) quand il tourne en arrière-plan ou sans terminal interactif.

### Solutions

#### 1. Forcer le flush immédiat (recommandé)

Modifier `core/multiscale.py` pour ajouter `flush=True` :

```python
print(f"⏳ CHECKPOINT [{current_percent:3d}%] - Chunk {chunk_counter}/{total_chunks}", flush=True)
print(f"   📍 Position : {processed_samples:,} / {n_samples:,} échantillons", flush=True)
# ... etc
```

#### 2. Désactiver le buffering Python

Lancer avec :
```bash
python -u run.py  # -u = unbuffered
```

Ou dans le code, au tout début de `run.py` :
```python
import sys
sys.stdout = sys.__stdout__  # Force unbuffered
```

#### 3. Utiliser un fichier de log

Dans `core/multiscale.py` :
```python
log_file = ms_path.parent / "pyramid_build.log"
with open(log_file, "a", encoding="utf-8") as log:
    log.write(f"[{time.strftime('%H:%M:%S')}] CHECKPOINT [{current_percent}%]\n")
    log.flush()
```

---

## 🎯 Recommandations

### Court Terme (Immédiat)

1. ✅ **Laisser le processus terminer** (~10-15 min restantes)
2. ✅ **Ne pas interrompre** (Ctrl+C invaliderait le store)
3. ✅ **Surveiller la taille** du dossier `_ms`

### Moyen Terme (Prochaine Version)

1. **Ajouter `flush=True`** à tous les `print()` dans `build_pyramid()`
2. **Créer un fichier de log** en parallèle des prints
3. **Afficher un avertissement** si plus de 50 canaux :
   ```python
   if n_channels > 50:
       print(f"⚠️  Fichier volumineux ({n_channels} canaux)")
       print(f"   Temps estimé : ~{n_channels/16 * 5:.0f} minutes")
   ```

### Long Terme

1. **Barre de progression dans l'UI** (tkinter ProgressBar)
2. **Notification système** à la fin
3. **Optimisation multi-thread** pour les gros fichiers (>50 canaux)

---

## 📝 Timeline Complète

| Heure | Événement |
|-------|-----------|
| ~22:15 | Début de la construction (arrière-plan) |
| 22:20 | +5 min - Pas de checkpoint visible |
| 22:28 | +13 min - Monitoring manuel : 25,954 fichiers, 5.8 GB |
| 22:32 | +17 min - Monitoring : 38,735 fichiers, 5.8 GB (en cours) |
| ~22:40 | +25 min - Fin estimée |

---

## ✅ Verdict

**Le processus est NORMAL et SAIN**.

Le temps de construction plus long est **attendu** pour un fichier avec **90 canaux** (au lieu de 16 typiques).

**Temps total réel** : 15-25 minutes (au lieu de 4-5 min standard).

---

**CESA v3.0** - Diagnostic technique  
Développé par Côme Barmoy (Unité Neuropsychologie du Stress - IRBA)



