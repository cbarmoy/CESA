# 🐛 Bugfix : Paramètre `chunk_bins` Manquant

**Date** : 2025-10-29  
**Priorité** : 🔴 **CRITIQUE** (bloque la création de pyramide)  
**Statut** : ✅ **CORRIGÉ**

---

## 🔍 Symptôme

Lors de la création d'une pyramide multiscale, l'erreur suivante apparaît :

```python
TypeError: LevelDescriptor.__init__() missing 1 required positional argument: 'chunk_bins'
```

**Traceback complet** :
```
File "core/multiscale.py", line 173, in build_pyramid
    store = _open_multiscale_writable(ms_path, root_group)
File "core/multiscale.py", line 277, in _open_multiscale_writable
    LevelDescriptor(bin_size=bin_size, dataset=dataset, n_bins=n_bins)
    ~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
TypeError: LevelDescriptor.__init__() missing 1 required positional argument: 'chunk_bins'
```

---

## 🕵️ Cause Racine

### Définition de `LevelDescriptor`

Dans `core/store.py:32-39`, `LevelDescriptor` est défini avec **4 paramètres obligatoires** :

```python
@dataclass(frozen=True)
class LevelDescriptor:
    """Descriptor for a single min/max pyramid level."""

    bin_size: int
    dataset: zarr.Array
    n_bins: int
    chunk_bins: int  # ← Paramètre manquant !
```

### Utilisation dans `_open_multiscale_writable`

Mais dans `core/multiscale.py:277`, la création de `LevelDescriptor` **n'incluait que 3 paramètres** :

```python
descriptors.append(
    LevelDescriptor(bin_size=bin_size, dataset=dataset, n_bins=n_bins)  # ❌ chunk_bins manquant !
)
```

**Résultat** : `TypeError` lors de l'initialisation du dataclass.

---

## ✅ Solution

### Récupération de `chunk_bins` depuis Zarr

Les datasets Zarr stockent leurs informations de chunking dans l'attribut `.chunks`.

**Code corrigé** dans `core/multiscale.py:276-279` :

```python
level_group = group["levels"]
descriptors = []
for bin_size in levels_list:
    level_name = f"lvl{bin_size}"
    dataset = level_group[level_name]
    n_bins = dataset.shape[1]
    chunk_bins = dataset.chunks[1]  # ✅ Récupérer chunk_bins depuis les chunks Zarr
    descriptors.append(
        LevelDescriptor(bin_size=bin_size, dataset=dataset, n_bins=n_bins, chunk_bins=chunk_bins)
    )
```

### Pourquoi `.chunks[1]` ?

Les datasets Zarr multiscale ont la forme :
```
(n_channels, n_bins, 2)
 └─ dimension 0  └─ dimension 1  └─ dimension 2
```

Le chunking correspond à `(1, chunk_bins, 2)`, donc :
- `.chunks[0]` = 1 (un canal à la fois)
- `.chunks[1]` = `chunk_bins` (nombre de bins par chunk temporel)
- `.chunks[2]` = 2 (min/max)

---

## 🔍 Vérification dans `open_multiscale`

La fonction `open_multiscale` dans `core/store.py` **fait déjà cela correctement** (ligne 161-167) :

```python
chunk_bins = dataset.chunks[1] if dataset.chunks else n_bins
level_descriptors.append(
    LevelDescriptor(
        bin_size=bin_size,
        dataset=dataset,
        n_bins=n_bins,
        chunk_bins=chunk_bins,  # ✅ Correctement fourni
    )
)
```

Le problème était uniquement dans `_open_multiscale_writable`, qui est une fonction privée utilisée pendant la **construction** de la pyramide.

---

## 📊 Impact

| Avant | Après |
|-------|-------|
| ❌ `TypeError` immédiat | ✅ Création de pyramide réussie |
| ❌ Impossible de créer un fichier de navigation rapide | ✅ Fonctionnel |
| ❌ Bloque totalement le mode pré-calculé | ✅ Mode pré-calculé opérationnel |

---

## 🧪 Test de Validation

### Test Manuel

1. Lancer CESA : `python run.py`
2. Ouvrir un fichier EDF
3. Choisir "⚡ Navigation Rapide"
4. Laisser le champ de chemin vide
5. Cliquer "Oui" pour créer le fichier

**✅ Résultat attendu** : La pyramide se crée sans erreur.

**Console attendue** :
```
🔧 Création du fichier de navigation rapide: <path>/_ms
⏳ Construction en cours...
```

### Test de Reprise

Si la construction est interrompue (Ctrl+C), relancer CESA et choisir le même fichier :

**✅ Résultat attendu** : Reprise depuis le dernier chunk traité (grâce à `resume=True`).

---

## 📝 Fichiers Modifiés

### `core/multiscale.py:276-279`

**Avant** :
```python
n_bins = dataset.shape[1]
descriptors.append(
    LevelDescriptor(bin_size=bin_size, dataset=dataset, n_bins=n_bins)
)
```

**Après** :
```python
n_bins = dataset.shape[1]
chunk_bins = dataset.chunks[1]  # ✅ Ajouté
descriptors.append(
    LevelDescriptor(bin_size=bin_size, dataset=dataset, n_bins=n_bins, chunk_bins=chunk_bins)
)
```

---

## 🎯 Leçons Apprises

1. **Dataclasses strictes** : Les `@dataclass` sans valeurs par défaut exigent **tous** les paramètres lors de l'initialisation.
2. **Cohérence inter-fonctions** : Si `open_multiscale` fournit `chunk_bins`, `_open_multiscale_writable` doit faire de même.
3. **Tests de création** : Les tests de lecture seuls (comme `open_multiscale`) ne détectent pas les bugs dans les fonctions d'écriture.

---

## ✅ Conclusion

Le paramètre `chunk_bins` manquant dans `_open_multiscale_writable` a été **corrigé** en récupérant la valeur depuis `.chunks[1]` du dataset Zarr.

**Statut final** : ✅ **RÉSOLU**

---

**CESA v3.0** - Bugfix technique  
Développé par Côme Barmoy (Unité Neuropsychologie du Stress - IRBA)



