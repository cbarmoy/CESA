# 🚀 Guide de Lancement CESA v3.0

## ✅ Système de Lancement Unifié

CESA v3.0 utilise un système de lancement simple et robuste avec détection automatique de Python.

---

## 🎯 Solution Implémentée

### **Lanceur Unique : `run.py`**

Un seul fichier Python dans le répertoire racine qui :
- ✅ **Vérifie** les dépendances
- ✅ **Affiche** un splash screen avec logos
- ✅ **Lance** l'application principale
- ✅ **Gère** les erreurs gracieusement

### **Lanceur Windows : `RUN.bat`**

Un script batch qui :
- ✅ **Détecte** Python automatiquement
- ✅ **Recherche** dans tous les emplacements standards
- ✅ **Lance** `run.py`
- ✅ **Affiche** des messages clairs

---

## 🛠️ Architecture du Système

### 📄 Fichier `run.py` (Racine)

**Localisation** : Répertoire racine du projet  
**Fonction** : Lanceur principal universel

**Fonctionnalités** :
```python
def main():
    """Fonction principale de lancement."""
    print("CESA (Complex EEG Studio Analysis) v3.0")
    
    # 1. Vérification des dépendances
    if not check_dependencies():
        return 1
    
    # 2. Affichage du splash screen
    splash_root, close_splash = show_splash()
    
    # 3. Lancement de l'application
    from CESA.eeg_studio_fixed import EEGAnalysisStudio
    app = EEGAnalysisStudio(splash_root)
    
    return 0
```

**Vérifications Incluses** :
- **Dépendances Python** : MNE, NumPy, SciPy, Matplotlib, Pandas, YASA
- **Tkinter** : Interface graphique
- **Modules CESA** : Tous les modules internes

### 📄 Fichier `RUN.bat` (Windows)

**Localisation** : Répertoire racine du projet  
**Fonction** : Détection automatique de Python sur Windows

**Algorithme** :
```batch
1. Essayer 'python' dans le PATH
2. Si échec → Rechercher dans les emplacements standards :
   - C:\Users\%USERNAME%\AppData\Local\Programs\Python\
   - C:\Program Files\Python311, Python310, Python39, Python38
   - C:\Python311, C:\Python310, etc.
3. Pour chaque Python trouvé → Tester avec --version
4. Lancer run.py avec le premier Python valide
5. Si aucun Python → Afficher message d'erreur avec instructions
```

**Avantages** :
- ✅ **Robuste** : Fonctionne même si Python n'est pas dans le PATH
- ✅ **Informatif** : Messages clairs à chaque étape
- ✅ **Fallback** : Instructions si aucun Python trouvé

---

## 🎯 Méthodes de Lancement

### 🥇 Méthode 1 : Lanceur Windows (Recommandé)

**Windows uniquement**

1. **Double-cliquez** sur `RUN.bat`
2. Le script détecte Python automatiquement
3. CESA se lance

**Messages Affichés** :
```
CESA - Comprehensive EEG Studio for Analysis
=============================================

[OK] Python trouvé dans le PATH
Python 3.13.5

[LANCEMENT] Lancement de CESA...
CESA (Complex EEG Studio Analysis) v3.0
==================================================
Vérification des dépendances...
✅ Toutes les dépendances sont disponibles.

Lancement de CESA v3.0...
```

### 🥈 Méthode 2 : Ligne de Commande (Universel)

**Windows, Linux, macOS**

```bash
# Depuis le répertoire racine
python run.py

# Ou avec python3
python3 run.py

# Ou avec py (Windows)
py run.py
```

**Avantages** :
- ✅ **Universel** : Fonctionne sur tous les OS
- ✅ **Direct** : Pas d'intermédiaire
- ✅ **Logs** : Affiche tous les messages dans le terminal

### 🥉 Méthode 3 : Installation Complète

**Pour première utilisation**

```bash
# Windows
INSTALL.bat

# Linux/macOS
pip install -r documentation/requirements.txt
python run.py
```

**Actions Effectuées** :
- ✅ **Vérification** de Python
- ✅ **Installation** des dépendances
- ✅ **Test** de lancement
- ✅ **Configuration** du système

---

## 🔧 Résolution des Problèmes

### ❌ "Python non trouvé"

**Symptômes** :
```
[ERREUR] Python non trouve!

[SOLUTION]:
   1. Installez Python depuis https://www.python.org/downloads/
   2. Cochez "Add Python to PATH" pendant l'installation
   3. Ou ajoutez Python manuellement au PATH systeme
```

**Solutions** :

#### Solution 1 : Installer Python
1. **Téléchargez** Python 3.8+ depuis https://www.python.org/downloads/
2. **Lancez** l'installateur
3. **⚠️ IMPORTANT** : Cochez "Add Python to PATH"
4. **Installez** avec les options par défaut
5. **Testez** : Ouvrez un nouveau terminal et tapez `python --version`

#### Solution 2 : Ajouter au PATH Manuellement
1. **Trouvez** le chemin d'installation de Python
   - Généralement : `C:\Users\VotreNom\AppData\Local\Programs\Python\Python3XX`
2. **Ouvrez** : Paramètres Windows → Système → Paramètres système avancés
3. **Variables d'environnement** → PATH → Modifier
4. **Ajoutez** le chemin vers Python et Python\Scripts
5. **Redémarrez** le terminal

#### Solution 3 : Utiliser le Chemin Complet
```bash
# Windows - exemple
C:\Users\VotreNom\AppData\Local\Programs\Python\Python313\python.exe run.py

# Trouvez votre Python avec :
where python
```

### ❌ "Module manquant"

**Symptômes** :
```
❌ Dépendances manquantes:
   - MNE-Python

Pour installer les dépendances:
   pip install -r documentation/requirements.txt
```

**Solutions** :

#### Solution 1 : Installation Automatique
```bash
# Windows
INSTALL.bat

# Linux/macOS
pip install -r documentation/requirements.txt
```

#### Solution 2 : Installation Manuelle
```bash
# Modules principaux
pip install mne>=1.4.0
pip install numpy>=1.21.0
pip install scipy>=1.7.0
pip install matplotlib>=3.5.0
pip install pandas>=1.3.0

# Modules Excel
pip install xlrd>=2.0.0
pip install openpyxl>=3.0.0

# Analyses avancées
pip install scikit-learn>=1.0.0
pip install statsmodels>=0.13.0
pip install yasa>=0.6.0
```

#### Solution 3 : Vérification
```bash
# Lister les modules installés
pip list

# Vérifier un module spécifique
pip show mne
```

### ❌ "Erreur lors du lancement"

**Solutions** :

#### Vérifier la Structure du Projet
```
CESA 3.0/
├── run.py                  ✅ Doit exister
├── RUN.bat                 ✅ Doit exister
└── CESA/
    ├── __init__.py         ✅ Doit exister
    └── eeg_studio_fixed.py ✅ Doit exister
```

#### Vérifier les Imports
```python
# Tester l'import du module principal
python -c "from CESA.eeg_studio_fixed import EEGAnalysisStudio; print('OK')"
```

#### Consulter les Logs
- **Ouvrez** un terminal
- **Lancez** : `python run.py`
- **Lisez** les messages d'erreur
- **Notez** le nom du module ou fichier manquant

---

## 📊 Architecture Simplifiée

### Avant (Multiples Lanceurs - Obsolète)
```
❌ CESA/run.py              (supprimé)
❌ CESA/launch_cesa.py      (supprimé)
❌ CESA/launch_new.py       (supprimé)
❌ START_CESA.bat           (supprimé)
❌ LAUNCH_CESA.bat          (supprimé)
```

### Maintenant (Structure Unifiée - v3.0)
```
✅ run.py                   (racine - lanceur principal)
✅ RUN.bat                  (racine - wrapper Windows)
✅ INSTALL.bat              (racine - installation)
```

**Avantages** :
- ✅ **Simple** : Un seul lanceur principal
- ✅ **Clair** : Pas de confusion
- ✅ **Maintenable** : Facile à mettre à jour
- ✅ **Professionnel** : Structure standard

---

## 🎨 Fonctionnalités du Lanceur

### Splash Screen
- **Logos** : IRBA + CESA affichés au centre
- **Chargement** : Pendant l'initialisation
- **Disparition** : Automatique quand l'app est prête

### Vérification des Dépendances
- **Automatique** : Liste les modules manquants
- **Informative** : Commandes pour installer
- **Bloquante** : Ne lance pas si dépendances manquantes

### Gestion d'Erreurs
- **Messages clairs** : Explication de chaque erreur
- **Suggestions** : Solutions proposées
- **Support** : Contact affiché si besoin

---

## 📚 Références Techniques

### Fichiers Principaux

| Fichier | Rôle | Plateforme |
|---------|------|------------|
| `run.py` | Lanceur principal | Universel |
| `RUN.bat` | Détection Python | Windows |
| `INSTALL.bat` | Installation complète | Windows |

### Dépendances Vérifiées

| Module | Version Min | Rôle |
|--------|-------------|------|
| mne | 1.4.0 | EDF+, analyses avancées |
| numpy | 1.21.0 | Calcul numérique |
| scipy | 1.7.0 | Traitement du signal |
| matplotlib | 3.5.0 | Visualisation |
| pandas | 1.3.0 | Manipulation de données |
| yasa | 0.6.0 | Scoring automatique |

---

## 🎉 Résultat Final

### ✅ Système Robuste
- **Détection automatique** : Python trouvé sur tous les systèmes
- **Messages clairs** : Utilisateur guidé à chaque étape
- **Fallback intelligent** : Solutions proposées en cas d'erreur

### ✅ Structure Professionnelle
- **Un seul lanceur** : `run.py` dans la racine
- **Un wrapper Windows** : `RUN.bat` avec détection auto
- **Installation facile** : `INSTALL.bat` tout-en-un

### ✅ CESA v3.0 Opérationnel
- **Lance sans problème** : Sur Windows, Linux, macOS
- **Vérifie les dépendances** : Avant de lancer
- **Guide l'utilisateur** : Messages informatifs

---

## 🚀 Guide Rapide

### Pour Lancer CESA :

**Windows :**
```
Double-cliquez sur RUN.bat
```

**Linux/macOS :**
```bash
python run.py
```

### En Cas de Problème :

1. **Vérifiez Python** : `python --version`
2. **Installez les dépendances** : `pip install -r documentation/requirements.txt`
3. **Relancez** : `python run.py`
4. **Consultez la doc** : `README.md`

---

**Développé avec ❤️ pour l'Unité Neuropsychologie du Stress (IRBA)**  
**Auteur** : Côme Barmoy  
**Version** : 3.0.0  
**Date** : 2025-10-26  
**Licence** : MIT

---

*CESA v3.0 - Système de lancement unifié, robuste et professionnel*
