# ✨ Feature : Interface de Sélection des Canaux

**Date** : 2025-10-29  
**Demande** : Permettre à l'utilisateur de choisir les canaux à inclure dans la pyramide  
**Statut** : ✅ **IMPLÉMENTÉ**

---

## 🎯 Objectif

Permettre à l'utilisateur de **sélectionner manuellement** les canaux à inclure dans le fichier de navigation rapide, car :
1. **Fichiers variables** : Les fichiers PSG n'ont pas toujours les mêmes canaux
2. **Flexibilité** : L'utilisateur peut vouloir analyser d'autres canaux que ceux pré-sélectionnés
3. **Optimisation** : Choisir uniquement les canaux nécessaires réduit le temps de construction

---

## 🖼️ Interface Utilisateur

### Dialogue de Sélection

```
┌────────────────────────────────────────────────┐
│  🔧 Sélection des Canaux pour la Pyramide     │
├────────────────────────────────────────────────┤
│  Choisissez les canaux à inclure dans le      │
│  fichier de navigation rapide.                 │
│  Plus vous sélectionnez de canaux, plus la    │
│  construction sera longue.                     │
│                                                │
│  📊 Total disponible : 90 canaux               │
│  ✅ Sélectionnés : 11 canaux                   │
│                                                │
│  ⚡ Sélection Rapide                           │
│  ┌──────────────────────────────────────────┐ │
│  │ [✅ Tout] [❌ Rien] [⭐ Pré-sélection]   │ │
│  │ [EEG (6)] [EOG (2)] [EMG (2)] [ECG (1)] │ │
│  └──────────────────────────────────────────┘ │
│                                                │
│  📋 Liste des Canaux                           │
│  ┌──────────────────────────────────────────┐ │
│  │ ━━━ EEG (6 canaux) ━━━                  │ │
│  │   ☑ F3-M2                                │ │
│  │   ☑ F4-M1                                │ │
│  │   ☑ C3-M2                                │ │
│  │   ☑ C4-M1                                │ │
│  │   ☑ O1-M2                                │ │
│  │   ☑ O2-M1                                │ │
│  │                                          │ │
│  │ ━━━ EOG (2 canaux) ━━━                  │ │
│  │   ☑ E1-M2                                │ │
│  │   ☑ E2-M1                                │ │
│  │                                          │ │
│  │ ━━━ EMG (2 canaux) ━━━                  │ │
│  │   ☑ Left Leg                             │ │
│  │   ☑ Right Leg                            │ │
│  │                                          │ │
│  │ ━━━ ECG (1 canal) ━━━                   │ │
│  │   ☑ Heart Rate                           │ │
│  │                                          │ │
│  │ ━━━ Respiration (12 canaux) ━━━         │ │
│  │   ☐ Airflow                              │ │
│  │   ☐ Nasal Pressure                       │ │
│  │   ☐ Abdomen                              │ │
│  │   ...                                    │ │
│  │                                          │ │
│  │ ━━━ Autres (67 canaux) ━━━              │ │
│  │   ☐ 1 Impédance                          │ │
│  │   ☐ 2 Impédance                          │ │
│  │   ...                                    │ │
│  └──────────────────────────────────────────┘ │
│                                                │
│  ⏱️  Temps estimé : ~1.8 minutes               │
│                                                │
│               [❌ Annuler]  [✅ Confirmer]      │
└────────────────────────────────────────────────┘
```

---

## 🔧 Fonctionnalités

### 1. Détection Automatique des Types

Les canaux sont automatiquement classés par type :
- **EEG** : F3, F4, C3, C4, O1, O2, P3, P4, T3, T4, Fp1, Fp2, Fz, Cz, Pz, -M1, -M2, -A1, -A2
- **EOG** : E1, E2, EOG, LOC, ROC, Eye
- **EMG** : Leg, Chin, EMG, Jambe, Menton
- **ECG** : ECG, Heart, Cardiac, Coeur, Rate
- **Respiration** : Flow, Airflow, Nasal, Abdomen, Chest, Thorax, Resp, Snor
- **SpO2** : SpO2, Sat, Pulse, Oxygen
- **Autres** : Tous les canaux non classés

---

### 2. Sélection Rapide

#### Boutons Globaux
- **✅ Tout sélectionner** : Sélectionne tous les canaux disponibles
- **❌ Tout désélectionner** : Désélectionne tous les canaux
- **⭐ Pré-sélection UI** : Sélectionne les canaux pré-définis pour l'UI (11 canaux)

#### Boutons par Type
- **EEG (6)** : Sélectionne tous les canaux EEG
- **EOG (2)** : Sélectionne tous les canaux EOG
- **EMG (2)** : Sélectionne tous les canaux EMG
- **ECG (1)** : Sélectionne tous les canaux ECG
- **Respiration (12)** : Sélectionne tous les canaux de respiration
- etc.

---

### 3. Statistiques en Temps Réel

- **Total disponible** : Nombre de canaux dans le fichier EDF
- **Sélectionnés** : Nombre de canaux actuellement cochés
- **Temps estimé** : Estimation du temps de construction basée sur le nombre de canaux

**Formule** : `temps_estimé = (n_canaux_sélectionnés / 90) × 15 minutes`

---

### 4. Organisation par Type

Les canaux sont regroupés par catégorie avec un titre :
```
━━━ EEG (6 canaux) ━━━
  ☑ F3-M2
  ☑ F4-M1
  ...

━━━ EOG (2 canaux) ━━━
  ☑ E1-M2
  ☑ E2-M1
```

---

## 📋 Workflow Utilisateur

### Étape 1 : Chargement du Fichier

```
1. Ouvrir un fichier EDF dans CESA
2. Les canaux sont chargés et analysés
```

---

### Étape 2 : Choix du Mode

```
┌─────────────────────────────────────────┐
│  Mode de Chargement                     │
├─────────────────────────────────────────┤
│  ⚡ Navigation Rapide (Recommandé)      │
│  📂 Mode Standard                       │
└─────────────────────────────────────────┘
```

---

### Étape 3 : Sélection des Canaux (NOUVEAU)

```
┌─────────────────────────────────────────┐
│  🔧 Sélection des Canaux                │
├─────────────────────────────────────────┤
│  [Liste des canaux disponibles]         │
│  [Boutons de sélection rapide]          │
│  [Temps estimé]                         │
│                                         │
│  [❌ Annuler]  [✅ Confirmer]           │
└─────────────────────────────────────────┘
```

**Options** :
- **⭐ Pré-sélection UI** : Utilise les 11 canaux pré-définis (rapide)
- **Sélection manuelle** : Coche/décoche individuellement
- **Par type** : Sélectionne tous les EEG, EOG, etc.
- **Annuler** : Retour au mode standard

---

### Étape 4 : Construction de la Pyramide

```
🔧 Création du fichier de navigation rapide: ...\\_ms
   📊 Canaux sélectionnés : ['F3-M2', 'F4-M1', ...]
   ⚡ Utilisation de 11 canaux sur 90 disponibles
   ⏱️  Temps estimé: ~1.8 minutes

🚀 Démarrage de la construction de la pyramide
   📊 Données : 11 canaux, 5,832,000 échantillons
   ...

⏳ CHECKPOINT [ 10%] - Chunk 145/1458
   ⏱️  Écoulé : 15s | Restant : ~135s
...
✅ Pyramide construite avec succès !
```

---

## 🎯 Cas d'Usage

### Cas 1 : Fichier Standard PSG

**Situation** : Fichier PSG standard avec tous les canaux habituels

**Action** :
1. Cliquer sur **⭐ Pré-sélection UI**
2. Confirmer

**Résultat** : 11 canaux sélectionnés, construction en 2-3 minutes

---

### Cas 2 : Analyse EEG Uniquement

**Situation** : L'utilisateur ne veut que les canaux EEG

**Action** :
1. Cliquer sur **❌ Tout désélectionner**
2. Cliquer sur **EEG (6)**
3. Confirmer

**Résultat** : 6 canaux EEG sélectionnés, construction en ~1 minute

---

### Cas 3 : Analyse Complète

**Situation** : L'utilisateur veut tous les canaux (analyse exhaustive)

**Action** :
1. Cliquer sur **✅ Tout sélectionner**
2. Confirmer (accepter le temps estimé de 15-20 min)

**Résultat** : 90 canaux sélectionnés, construction en 15-20 minutes

---

### Cas 4 : Canaux Personnalisés

**Situation** : L'utilisateur veut des canaux spécifiques (ex: EEG + Respiration)

**Action** :
1. Cliquer sur **❌ Tout désélectionner**
2. Cliquer sur **EEG (6)**
3. Cliquer sur **Respiration (12)**
4. Confirmer

**Résultat** : 18 canaux sélectionnés, construction en ~3 minutes

---

## 📊 Comparaison Avant/Après

| Aspect | Avant | Après |
|--------|-------|-------|
| **Sélection de canaux** | ❌ Automatique (pré-sélection fixe) | ✅ **Manuelle (dialogue)** |
| **Flexibilité** | ❌ Limitée (11 canaux fixés) | ✅ **Total (0-90 canaux)** |
| **Types de canaux** | ❌ Non visible | ✅ **Classement automatique** |
| **Temps estimé** | ❌ Non affiché | ✅ **Mis à jour en temps réel** |
| **Sélection rapide** | ❌ Non disponible | ✅ **Boutons par type** |
| **Annulation** | ❌ Non possible | ✅ **Retour au mode standard** |

---

## 🔧 Implémentation Technique

### Nouveau Fichier : `ui/channel_selector.py`

```python
class ChannelSelector:
    """Dialogue de sélection des canaux pour la pyramide multiscale."""
    
    def __init__(self, parent, available_channels, preselected_channels=None):
        # Initialisation avec détection automatique des types
        self.channel_types = self._detect_channel_types()
    
    def _detect_channel_types(self) -> Dict[str, List[str]]:
        """Détecte automatiquement les types de canaux."""
        # Classement par type (EEG, EOG, EMG, ECG, etc.)
    
    def show_dialog(self) -> Optional[List[str]]:
        """Affiche le dialogue et retourne la sélection."""
        # Création de l'interface Tkinter
        # Checkbuttons pour chaque canal
        # Boutons de sélection rapide
        # Calcul du temps estimé
    
    def get_selection(self) -> Optional[List[str]]:
        """Retourne la liste des canaux sélectionnés ou None si annulé."""
```

---

### Modification de `CESA/eeg_studio_fixed.py`

```python
# Avant la construction de la pyramide
from ui.channel_selector import ChannelSelector

# Afficher le sélecteur
channel_selector = ChannelSelector(
    parent=self.root,
    available_channels=list(self.raw.ch_names),
    preselected_channels=self.selected_channels
)

selected_channels = channel_selector.get_selection()

if selected_channels is None:
    # Annulé → retour au mode standard
    return

# Construction avec les canaux sélectionnés
build_pyramid(
    raw_source=self.raw,
    out_ms_path=ms_path,
    selected_channels=selected_channels
)
```

---

## 🎯 Avantages

### Pour l'Utilisateur

1. ✅ **Contrôle total** : Choisit exactement les canaux nécessaires
2. ✅ **Visibilité** : Voit tous les canaux disponibles et leur type
3. ✅ **Rapidité** : Sélection rapide par type (1 clic pour tous les EEG)
4. ✅ **Estimation** : Connaît le temps de construction avant de commencer
5. ✅ **Annulation** : Peut revenir en arrière sans conséquence

### Pour le Développeur

1. ✅ **Flexibilité** : Supporte n'importe quel fichier EDF
2. ✅ **Maintenabilité** : Code modulaire (`ChannelSelector` indépendant)
3. ✅ **Extensibilité** : Facile d'ajouter de nouveaux types de canaux
4. ✅ **Robustesse** : Détection automatique des types
5. ✅ **UX** : Interface claire et intuitive

---

## 🔮 Améliorations Futures

### Court Terme
- [ ] Sauvegarder les préférences de sélection (JSON local)
- [ ] Recherche/filtre de canaux (barre de recherche)
- [ ] Import/Export de profils de sélection

### Moyen Terme
- [ ] Presets enregistrables ("Mon analyse PSG", "EEG complet", etc.)
- [ ] Suggestions intelligentes basées sur le fichier
- [ ] Aperçu du signal pour chaque canal

### Long Terme
- [ ] Détection automatique des canaux pertinents (ML)
- [ ] Recommandations basées sur l'historique
- [ ] Partage de profils entre utilisateurs

---

## 📝 Tests

### Test 1 : Sélection Basique

```python
# Lancer CESA
# Charger S043_Ap_EDF+.edf
# Choisir "Navigation Rapide"
# Observer le dialogue de sélection
```

**Attendu** :
- ✅ Dialogue affiché avec 90 canaux
- ✅ 11 canaux pré-cochés (pré-sélection UI)
- ✅ Canaux groupés par type
- ✅ Temps estimé : ~1.8 minutes

---

### Test 2 : Sélection par Type

```python
# Cliquer sur "Tout désélectionner"
# Cliquer sur "EEG (6)"
# Observer le compteur
```

**Attendu** :
- ✅ 6 canaux EEG cochés
- ✅ Compteur : "Sélectionnés : 6 canaux"
- ✅ Temps estimé : ~1.0 minute

---

### Test 3 : Annulation

```python
# Cliquer sur "Annuler" dans le dialogue
```

**Attendu** :
- ✅ Retour au mode standard
- ✅ Message : "Sélection annulée par l'utilisateur"
- ✅ Pas de construction de pyramide

---

## ✅ Conclusion

La fonctionnalité de **sélection manuelle des canaux** est maintenant **opérationnelle** et permet :
- ✅ **Flexibilité totale** : L'utilisateur choisit les canaux
- ✅ **Visibilité** : Classification automatique par type
- ✅ **Rapidité** : Sélection rapide par groupe
- ✅ **Optimisation** : Estimation du temps en temps réel

**Impact** : Supporte tous les types de fichiers PSG, quelle que soit leur configuration de canaux !

---

**CESA v3.0** - Feature: Interface de sélection des canaux  
Développé par Côme Barmoy (Unité Neuropsychologie du Stress - IRBA)



