### Méthodes statistiques robustes utilisées pour les graphiques spaghetti

Ce document décrit les trois méthodes robustes appliquées pour décider, par sujet/bande/canal, s’il y a augmentation, diminution ou stagnation entre AVANT et APRÈS. Toutes les méthodes partagent la même statistique de base pour la cohérence: la médiane des différences.

### Statistique de base

- **Définition**: `D_obs = median(X_après) - median(X_avant)`
- En cas d’appariement (même nombre d’époques): définir `d_i = x_après,i - x_avant,i` et `D_obs = median(d_i)`.

Code (extrait):
```python
def _median_diff(x_before: np.ndarray, x_after: np.ndarray) -> Tuple[float, float, float]:
    med_b = float(np.median(x_before)) if x_before.size else np.nan
    med_a = float(np.median(x_after)) if x_after.size else np.nan
    return med_a - med_b, med_b, med_a
```

### 1) Test de permutation (sign-flip apparié ou non-apparié)

- **But**: Estimer la probabilité (p-valeur) d’observer un `|D_obs|` au moins aussi extrême sous l’hypothèse nulle d’absence d’effet.
- **Cas apparié** (tailles égales): tirages aléatoires de signes ±1 appliqués aux différences `d_i` puis calcul de `median(± d_i)`.
- **Cas non-apparié**: permutations entre paquets AVANT/APRÈS, calcul de `median(x_après) - median(x_avant)` après réaffectation.
- **Décision**: si `p < alpha` (par défaut 0,05), alors « augmentation » si `D_obs > 0`, « diminution » si `D_obs < 0`, sinon « stagnation ».

Code (extrait):
```python
def permutation_test_median_diff(x_before: np.ndarray,
                                 x_after: np.ndarray,
                                 n_perm: int = N_PERM,
                                 random_state: int = RNG_SEED) -> Dict[str, float | str]:
    d_obs, med_b, med_a = _median_diff(x_before, x_after)
    n1, n2 = x_before.size, x_after.size
    rng = np.random.default_rng(random_state)
    if n1 == n2:
        diffs = x_after - x_before
        d0 = float(np.median(diffs))
        count = 0
        for _ in range(n_perm):
            signs = rng.choice([-1, 1], size=n1)
            d_perm = float(np.median(signs * diffs))
            if abs(d_perm) >= abs(d0):
                count += 1
        p_val = count / n_perm
    else:
        d0 = float(d_obs)
        combined = np.concatenate([x_before, x_after])
        count = 0
        for _ in range(n_perm):
            perm = rng.permutation(combined)
            x1 = perm[:n1]
            x2 = perm[n1:]
            d_perm = float(np.median(x2) - np.median(x1))
            if abs(d_perm) >= abs(d0):
                count += 1
        p_val = count / n_perm
    # décision sur alpha
    decision = 'augmentation' if (not np.isnan(d0) and p_val < ALPHA and d0 > 0) else (
        'diminution' if (not np.isnan(d0) and p_val < ALPHA and d0 < 0) else 'stagnation')
    return {'D_obs': float(d0), 'Median_Avant': float(med_b), 'Median_Apres': float(med_a), 'p_value': float(p_val), 'decision': decision}
```

### 2) Intervalle de confiance bootstrap pour la médiane des différences

- **But**: Estimer un IC à 95 % (par défaut) de `D_obs` en reséchant avec remise.
- **Cas apparié**: bootstrap d’indices sur les différences `d_i` et `median(d_i)`.
- **Cas non-apparié**: bootstrap indépendant sur AVANT et APRÈS, puis différence des médianes.
- **Décision**: « augmentation » si IC entièrement > 0, « diminution » si IC entièrement < 0, sinon « stagnation ».

Code (extrait):
```python
def bootstrap_ci_median_diff(x_before: np.ndarray,
                             x_after: np.ndarray,
                             n_boot: int = N_BOOT,
                             ci: float = 0.95,
                             random_state: int = RNG_SEED) -> Dict[str, float | str]:
    rng = np.random.default_rng(random_state)
    n1, n2 = x_before.size, x_after.size
    stats = np.empty(n_boot, dtype=float)
    if n1 == n2:
        diffs = x_after - x_before
        for i in range(n_boot):
            idx = rng.integers(0, n1, size=n1)
            stats[i] = float(np.median(diffs[idx]))
    else:
        for i in range(n_boot):
            b1 = x_before[rng.integers(0, n1, size=n1)]
            b2 = x_after[rng.integers(0, n2, size=n2)]
            stats[i] = float(np.median(b2) - np.median(b1))
    alpha = 1 - ci
    ci_low = float(np.percentile(stats, 100 * alpha / 2))
    ci_high = float(np.percentile(stats, 100 * (1 - alpha / 2)))
    decision = 'augmentation' if ci_low > 0 else ('diminution' if ci_high < 0 else 'stagnation')
    d_obs, med_b, med_a = _median_diff(x_before, x_after)
    return {'D_obs': float(d_obs), 'Median_Avant': float(med_b), 'Median_Apres': float(med_a), 'CI_low': ci_low, 'CI_high': ci_high, 'decision': decision}
```

### 3) Z robuste (basé sur la MAD)

- **But**: Mesurer l’ampleur de l’effet en unités robustes d’écart type, insensible aux valeurs extrêmes.
- **Calcul**:
  - Apparié: `d_i = x_après,i - x_avant,i`, `d0 = median(d_i)`, `MAD = median(|d_i - d0|)`, `Z = d0 / (1.4826 * MAD)`.
  - Non-apparié: bootstrap pour approximer la distribution de `D_obs`, puis MAD sur cette distribution.
- **Décision**: « augmentation » si `|Z| > T` et `Z > 0`, « diminution » si `|Z| > T` et `Z < 0`, sinon « stagnation ». Seuil par défaut `T = 2.5`.

Code (extrait):
```python
def robust_z_intrasubject(x_before: np.ndarray,
                          x_after: np.ndarray,
                          threshold: float = ROBUST_Z_THRESHOLD) -> Dict[str, float | str]:
    n1, n2 = x_before.size, x_after.size
    if n1 == n2:
        diffs = x_after - x_before
        d0 = float(np.median(diffs))
        mad = float(np.median(np.abs(diffs - d0)))
    else:
        rng = np.random.default_rng(RNG_SEED)
        n_boot = 1000
        stats = np.empty(n_boot, dtype=float)
        for i in range(n_boot):
            idx_b = rng.integers(0, n1, size=n1)
            idx_a = rng.integers(0, n2, size=n2)
            stats[i] = float(np.median(x_after[idx_a]) - np.median(x_before[idx_b]))
        d0 = float(np.median(stats))
        mad = float(np.median(np.abs(stats - d0)))
    scale = 1.4826 * mad if mad > 1e-10 else 1e-10
    z = float(d0 / scale)
    decision = 'augmentation' if (abs(z) > threshold and z > 0) else ('diminution' if (abs(z) > threshold and z < 0) else 'stagnation')
    d_obs, med_b, med_a = _median_diff(x_before, x_after)
    return {'D_obs': float(d_obs), 'Median_Avant': float(med_b), 'Median_Apres': float(med_a), 'Z': float(z), 'decision': decision}
```

### Règles de décision et consensus

- **Symboles par méthode**: ↑ (augmentation), ↓ (diminution), = (stagnation), ◦ (mixte)
- **Consensus**: si au moins 2 méthodes sur 3 s’accordent (↑ ou ↓), le consensus est marqué par « ★ » sur le point APRÈS.

### Cas limites et garde-fous

- Si une seule époque (1 AVANT et 1 APRÈS) ou des données insuffisantes: décision « stagnation » (p-valeur non calculée, Z non défini, IC non défini).
- Ces contrôles sont implémentés dans chaque méthode avant calcul.

Exemple (contrôle cas limites):
```python
# Cas limites: données insuffisantes OU 1 seule époque -> stagnation
if n1 == 0 or n2 == 0 or np.isnan(d_obs) or (n1 == 1 and n2 == 1):
    return {
        'D_obs': float(d_obs) if not np.isnan(d_obs) else np.nan,
        'Median_Avant': float(med_b) if not np.isnan(med_b) else np.nan,
        'Median_Apres': float(med_a) if not np.isnan(med_a) else np.nan,
        'p_value': np.nan,
        'decision': 'stagnation',
    }
```

### Paramètres et valeurs par défaut

- Nombre de permutations: `N_perm = 5000`
- Nombre de bootstrap: `N_boot = 2000`
- Seuil alpha: `alpha = 0.05`
- Seuil Z robuste: `T = 2.5`

Constantes (valeurs par défaut):
```python
RNG_SEED = 42
N_PERM = 5000
N_BOOT = 2000
ALPHA = 0.05
ROBUST_Z_THRESHOLD = 2.5
```

### Reproductibilité et logs

- Générateur aléatoire initialisé avec `RNG_SEED` pour reproductibilité.
- Des messages de log détaillent `D_obs`, `p`, `CI`, `Z` et la décision, pour vérification.

### Notes

- Toutes les méthodes opèrent sur la même statistique de base (médiane des différences) pour la cohérence inter-méthodes.
- Les décisions s’appliquent indépendamment par sujet/bande/canal/stade, puis un consensus (≥2/3) est évalué.


